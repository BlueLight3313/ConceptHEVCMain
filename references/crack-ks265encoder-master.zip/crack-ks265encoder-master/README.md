Cracking Ks265codec Encoder in ubuntu_x64
(https://github.com/ksvc/ks265codec)

Offering encode API like ffmpeg

Dependence:
1. ubuntu_x64 12.04 or higher
2. gdb install by apt-get
3. FFmpeg lib (already builded here)

Usage:
1. make
2. chmod 777 appencoder
2. run demo: ./demo -i test.yuv -w width -h height -f fps
3. use hevc_encoder API in your code as main.c
 
Warning:
This cracked-encoder ONLY for developers to learn, share and exchange use and not for other purposes. All copyright of the original publisher.

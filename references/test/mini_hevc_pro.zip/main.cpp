#include "enc_base.hpp"

extern "C" enc_base_c* create_encoder();

int main()
{
    enc_base_c* enc = create_encoder();

    enc->init();
    enc->encode();
    enc->flush();

    delete enc;

    return 0;
}

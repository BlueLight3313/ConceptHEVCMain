#ifndef PROFILE_HPP
#define PROFILE_HPP

enum hevc_profile_e
{
    HEVC_PROFILE_MAIN = 1,
    HEVC_PROFILE_MAIN10 = 2,
    HEVC_PROFILE_REXT = 3
};

struct profile_entry_s
{
    hevc_profile_e id;
    const char* name;
};

extern profile_entry_s g_profile_table[];

#endif

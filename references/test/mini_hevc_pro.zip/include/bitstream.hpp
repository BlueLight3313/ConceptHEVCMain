#ifndef BITSTREAM_HPP
#define BITSTREAM_HPP

class bitstream_c
{
private:
    unsigned total_bits;

public:
    bitstream_c();

    void write_bits(unsigned bits);
    unsigned get_total_bits() const;
};

#endif

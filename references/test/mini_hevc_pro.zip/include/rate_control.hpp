#ifndef RATE_CONTROL_HPP
#define RATE_CONTROL_HPP

class rate_control_c
{
private:
    unsigned target_bitrate;

public:
    rate_control_c(unsigned bitrate);

    void update(unsigned bits_used);
    unsigned get_target() const;
};

#endif

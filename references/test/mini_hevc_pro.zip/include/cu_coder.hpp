#ifndef CU_CODER_HPP
#define CU_CODER_HPP

#include "stat.hpp"

struct ctu_s
{
    unsigned x;
    unsigned y;
    unsigned size;
};

class cu_coder_c
{
public:
    virtual void encode_ctu(ctu_s& ctu, stat_c& stat) = 0;
    virtual ~cu_coder_c() {}
};

class simple_cu_coder_c : public cu_coder_c
{
public:
    void encode_ctu(ctu_s& ctu, stat_c& stat) override;
};

#endif

#ifndef ALLOCATOR_HPP
#define ALLOCATOR_HPP

#include <cstddef>

class allocator_c
{
public:
    virtual void* alloc(size_t size) = 0;
    virtual void free_mem(void* ptr) = 0;
    virtual ~allocator_c() {}
};

class default_allocator_c : public allocator_c
{
public:
    void* alloc(size_t size) override;
    void free_mem(void* ptr) override;
};

#endif

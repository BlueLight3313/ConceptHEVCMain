#ifndef STAT_HPP
#define STAT_HPP

class stat_c
{
public:
    unsigned bits;
    unsigned distortion;

    stat_c();
    void reset();
};

#endif

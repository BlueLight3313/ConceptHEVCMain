#ifndef ENC_BASE_HPP
#define ENC_BASE_HPP

class enc_base_c
{
public:
    static int g_active;

    enc_base_c();
    virtual ~enc_base_c();

    virtual void init() = 0;
    virtual void encode() = 0;
    virtual void flush() = 0;
};

#endif

#ifndef ENC_HEVC_IMPL_HPP
#define ENC_HEVC_IMPL_HPP

#include "enc_base.hpp"
#include "allocator.hpp"
#include "ctu_coder.hpp"
#include "rate_control.hpp"
#include "bitstream.hpp"
#include "stat.hpp"

class enc_hevc_impl_c :
    public enc_base_c,
    public allocator_c
{
private:
    ctu_coder_c* m_ctu;
    rate_control_c* m_rc;
    bitstream_c m_bs;
    stat_c m_stat;

public:
    enc_hevc_impl_c();
    ~enc_hevc_impl_c();

    void init() override;
    void encode() override;
    void flush() override;

    void* alloc(size_t size) override;
    void free_mem(void* ptr) override;
};

#endif

#ifndef CTU_CODER_HPP
#define CTU_CODER_HPP

#include "cu_coder.hpp"

class ctu_coder_c
{
private:
    cu_coder_c* m_cu;

public:
    ctu_coder_c(cu_coder_c* cu);
    void process_frame(unsigned width, unsigned height, stat_c& stat);
};

#endif

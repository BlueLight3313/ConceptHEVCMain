#include "enc_hevc_impl.hpp"
#include "cu_coder.hpp"
#include <iostream>
#include <cstdlib>

enc_hevc_impl_c::enc_hevc_impl_c()
{
    cu_coder_c* cu = new simple_cu_coder_c();
    m_ctu = new ctu_coder_c(cu);
    m_rc = new rate_control_c(50000);
}

enc_hevc_impl_c::~enc_hevc_impl_c()
{
    delete m_ctu;
    delete m_rc;
}

void enc_hevc_impl_c::init()
{
    std::cout << "HEVC encoder init\n";
}

void enc_hevc_impl_c::encode()
{
    m_stat.reset();
    m_ctu->process_frame(1920, 1080, m_stat);

    m_bs.write_bits(m_stat.bits);
    m_rc->update(m_stat.bits);
}

void enc_hevc_impl_c::flush()
{
    std::cout << "Bits: " << m_bs.get_total_bits() << "\n";
}

void* enc_hevc_impl_c::alloc(size_t size)
{
    return std::malloc(size);
}

void enc_hevc_impl_c::free_mem(void* ptr)
{
    std::free(ptr);
}

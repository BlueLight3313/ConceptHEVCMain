#include "rate_control.hpp"

rate_control_c::rate_control_c(unsigned bitrate)
    : target_bitrate(bitrate)
{
}

void rate_control_c::update(unsigned bits_used)
{
    if (bits_used > target_bitrate)
        target_bitrate += 1000;
}

unsigned rate_control_c::get_target() const
{
    return target_bitrate;
}

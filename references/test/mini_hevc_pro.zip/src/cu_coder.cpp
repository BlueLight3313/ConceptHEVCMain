#include "cu_coder.hpp"

void simple_cu_coder_c::encode_ctu(ctu_s& ctu, stat_c& stat)
{
    stat.bits += ctu.size * 4;
    stat.distortion += ctu.size * 2;
}

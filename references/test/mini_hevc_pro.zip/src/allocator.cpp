#include "allocator.hpp"
#include <cstdlib>

void* default_allocator_c::alloc(size_t size)
{
    return std::malloc(size);
}

void default_allocator_c::free_mem(void* ptr)
{
    std::free(ptr);
}

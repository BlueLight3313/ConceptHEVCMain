#include "ctu_coder.hpp"

ctu_coder_c::ctu_coder_c(cu_coder_c* cu)
    : m_cu(cu)
{
}

void ctu_coder_c::process_frame(unsigned width, unsigned height, stat_c& stat)
{
    const unsigned ctu_size = 64;

    for (unsigned y = 0; y < height; y += ctu_size)
    {
        for (unsigned x = 0; x < width; x += ctu_size)
        {
            ctu_s ctu = { x, y, ctu_size };
            m_cu->encode_ctu(ctu, stat);
        }
    }
}

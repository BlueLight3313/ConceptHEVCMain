#include "enc_base.hpp"

int enc_base_c::g_active = 0;

enc_base_c::enc_base_c()
{
    g_active++;
}

enc_base_c::~enc_base_c()
{
    g_active--;
}

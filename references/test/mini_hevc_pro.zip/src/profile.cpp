#include "profile.hpp"

profile_entry_s g_profile_table[] =
{
    { HEVC_PROFILE_MAIN, "Main" },
    { HEVC_PROFILE_MAIN10, "Main10" },
    { HEVC_PROFILE_REXT, "RangeExt" },
    { (hevc_profile_e)0, nullptr }
};

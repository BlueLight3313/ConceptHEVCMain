#include "enc_hevc_impl.hpp"

extern "C"
{
    enc_base_c* create_encoder()
    {
        return new enc_hevc_impl_c();
    }
}

#include "bitstream.hpp"

bitstream_c::bitstream_c()
    : total_bits(0)
{
}

void bitstream_c::write_bits(unsigned bits)
{
    total_bits += bits;
}

unsigned bitstream_c::get_total_bits() const
{
    return total_bits;
}

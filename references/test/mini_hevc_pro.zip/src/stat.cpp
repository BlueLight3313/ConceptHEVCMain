#include "stat.hpp"

stat_c::stat_c()
    : bits(0), distortion(0)
{
}

void stat_c::reset()
{
    bits = 0;
    distortion = 0;
}

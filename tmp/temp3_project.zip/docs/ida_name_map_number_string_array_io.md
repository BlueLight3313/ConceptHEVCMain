# IDA Rename Map (Analyzed So Far)

## Shared
- `sub_3B1F80` -> `safe_vsnprintf_clamped`
- `sub_3B4AA0` -> `field_io_query_meta`
- `throw_no_default_value` -> `throw_no_default_value`

## number_io<int>
- `sub_3B56C0` -> `number_io_int_set_from_text`
- `sub_3B4CE0` -> `number_io_int_get_to_text`
- `sub_3B4C70` -> `default_number_io_int_get_default_value`

## string_io
- `sub_3B4AB0` -> `string_io_get_capacity`
- `sub_3B5680` -> `string_io_set_from_text`
- `sub_3B4CC0` -> `string_io_get_to_text`

## array_io
- `sub_3B4AF0` -> `array_io_get_capacity`
- `sub_3B94F0` -> `array_io_set_from_text`
- `sub_3B6FD0` -> `array_io_get_to_text`

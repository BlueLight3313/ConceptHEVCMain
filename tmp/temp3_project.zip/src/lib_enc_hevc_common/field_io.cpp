#include "lib_enc_hevc_common/field_io.hpp"

#include <cstdarg>
#include <cstdio>
#include <stdexcept>

namespace __lib_enc_hevc_common__ {

std::size_t safe_vsnprintf_clamped(char* buffer, std::size_t size, const char* fmt, ...)
{
    if (!buffer || size == 0 || !fmt) {
        return 0;
    }

    va_list args;
    va_start(args, fmt);
    const int rc = std::vsnprintf(buffer, size, fmt, args);
    va_end(args);

    if (rc < 0) {
        buffer[0] = '\0';
        return 0;
    }

    const std::size_t n = static_cast<std::size_t>(rc);
    if (n >= size) {
        return size - 1; // sub_3B1F80 clamped behavior
    }
    return n;
}

[[noreturn]] void throw_no_default_value()
{
    throw std::runtime_error("no default value available");
}

std::int64_t field_io_query_meta(
    const field_desc_s* field_desc,
    std::int64_t,
    std::int64_t)
{
    if (!field_desc) {
        return 0;
    }
    return static_cast<std::int64_t>(field_desc->array_bytes);
}

} // namespace __lib_enc_hevc_common__

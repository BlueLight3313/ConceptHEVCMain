#include "lib_enc_hevc_common/array_io.hpp"
#include "lib_enc_hevc_common/number_io.hpp"

#include <cctype>
#include <cstring>
#include <stdexcept>
#include <string>

namespace __lib_enc_hevc_common__ {

std::int64_t array_io_get_capacity(std::int64_t, std::int64_t a2) // sub_3B4AF0
{
    return *reinterpret_cast<int*>(a2 + 32);
}

static std::size_t append_sep(char* out, std::size_t out_size, const char* sep)
{
    return safe_vsnprintf_clamped(out, out_size, "%s", sep ? sep : "");
}

std::int64_t array_io_set_from_text(void* a1, const char** a2, void* a3, const char* a4, const char* a5) // sub_3B94F0 (simplified)
{
    auto* self = reinterpret_cast<array_io_c*>(a1);
    return static_cast<std::int64_t>(
        self->set_from_text(reinterpret_cast<const field_desc_s*>(a2), a3, a4, a5));
}

std::size_t array_io_get_to_text(std::int64_t a1, std::int64_t a2, std::int64_t a3, char* a4, std::size_t a5) // sub_3B6FD0
{
    auto* self = reinterpret_cast<array_io_c*>(a1);
    return self->get_to_text(reinterpret_cast<const field_desc_s*>(a2), reinterpret_cast<const void*>(a3), a4, a5);
}

std::size_t array_io_c::set_from_text(
    const field_desc_s* field_desc,
    void* value_out,
    const char* key,
    const char* text)
{
    if (!field_desc || !value_out || !key || !text || !field_desc->key || !m_element_io) {
        return static_cast<std::size_t>(-1);
    }
    if (std::strcmp(key, field_desc->key) != 0) {
        return static_cast<std::size_t>(-1);
    }

    const std::size_t total_bytes = field_desc->array_bytes > 0 ? static_cast<std::size_t>(field_desc->array_bytes) : 0;
    const std::size_t elem_size   = field_desc->elem_size > 0   ? static_cast<std::size_t>(field_desc->elem_size)   : 0;
    const std::size_t min_elems   = field_desc->min_elems > 0   ? static_cast<std::size_t>(field_desc->min_elems)   : 0;

    if (total_bytes == 0 || elem_size == 0 || total_bytes % elem_size != 0) {
        return 0;
    }

    const std::size_t capacity = total_bytes / elem_size;
    char* dst = reinterpret_cast<char*>(value_out);

    const char* p = text;
    while (*p && std::isspace(static_cast<unsigned char>(*p))) ++p;

    const bool braced = (*p == '{');
    if (braced) ++p;

    std::size_t count = 0;
    const char* begin = p;

    while (count < capacity) {
        while (*p && std::isspace(static_cast<unsigned char>(*p))) ++p;

        std::size_t consumed = m_element_io->set_from_text(field_desc, dst + count * elem_size, key, p);
        if (consumed == 0 || consumed == static_cast<std::size_t>(-1)) {
            break;
        }
        ++count;
        p += consumed;

        while (*p && std::isspace(static_cast<unsigned char>(*p))) ++p;
        if (*p != ',') break;
        ++p;
    }

    if (count < min_elems) {
        throw std::runtime_error("that parameter must have at least " + std::to_string(min_elems) +
                                 " elements. Only " + std::to_string(count) + " detected");
    }

    for (std::size_t i = count; i < capacity; ++i) {
        m_element_io->get_default_value(dst + i * elem_size);
    }

    if (braced) {
        while (*p && std::isspace(static_cast<unsigned char>(*p))) ++p;
        if (*p == '}') ++p;
    }

    return static_cast<std::size_t>(p - begin + (braced ? 1 : 0));
}

std::size_t array_io_c::get_to_text(
    const field_desc_s* field_desc,
    const void* value_in,
    char* out,
    std::size_t out_size)
{
    if (!field_desc || !value_in || !out || out_size == 0 || !m_element_io) {
        return 0;
    }

    const std::size_t total_bytes = field_desc->array_bytes > 0 ? static_cast<std::size_t>(field_desc->array_bytes) : 0;
    const std::size_t elem_size   = field_desc->elem_size > 0   ? static_cast<std::size_t>(field_desc->elem_size)   : 0;
    if (total_bytes == 0 || elem_size == 0 || total_bytes % elem_size != 0) {
        return 0;
    }

    std::size_t n = safe_vsnprintf_clamped(out, out_size, "{");
    const std::size_t count = total_bytes / elem_size;
    const char* src = reinterpret_cast<const char*>(value_in);

    for (std::size_t i = 0; i < count; ++i) {
        if (i > 0) {
            n += append_sep(out + n, (n < out_size) ? (out_size - n) : 0, ", ");
        }
        n += m_element_io->get_to_text(
            field_desc,
            src + i * elem_size,
            out + n,
            (n < out_size) ? (out_size - n) : 0);
    }

    n += safe_vsnprintf_clamped(out + n, (n < out_size) ? (out_size - n) : 0, "}");
    return n;
}

std::int64_t array_io_c::query_meta(
    const field_desc_s* field_desc,
    std::int64_t a3,
    std::int64_t a4)
{
    return field_io_query_meta(field_desc, a3, a4);
}

std::int64_t array_io_c::get_default_value(void*)
{
    throw_no_default_value();
}

} // namespace __lib_enc_hevc_common__

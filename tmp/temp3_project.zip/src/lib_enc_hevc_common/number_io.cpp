#include "lib_enc_hevc_common/number_io.hpp"

#include <cstdio>
#include <cstring>

namespace __lib_enc_hevc_common__ {

namespace {

template<typename T>
inline T read_value(const void* ptr)
{
    return *reinterpret_cast<const T*>(ptr);
}

template<typename T>
inline void write_value(void* ptr, T v)
{
    *reinterpret_cast<T*>(ptr) = v;
}

template<typename T>
inline std::size_t number_io_set_impl(
    const char* scan_fmt,
    const field_desc_s* field_desc,
    void* value_out,
    const char* key,
    const char* text)
{
    if (!scan_fmt || !field_desc || !value_out || !key || !text || !field_desc->key) {
        return static_cast<std::size_t>(-1);
    }
    if (std::strcmp(key, field_desc->key) != 0) {
        return static_cast<std::size_t>(-1);
    }

    unsigned int consumed = 0;
    T v{};
    std::sscanf(text, scan_fmt, &v, &consumed);
    write_value<T>(value_out, v);
    return static_cast<std::size_t>(consumed);
}

} // namespace

template<typename T>
std::size_t number_io_c<T>::set_from_text(
    const field_desc_s* field_desc,
    void* value_out,
    const char* key,
    const char* text)
{
    return number_io_set_impl<T>(m_scan_fmt, field_desc, value_out, key, text);
}

template<typename T>
std::size_t number_io_c<T>::get_to_text(
    const field_desc_s*,
    const void* value_in,
    char* out,
    std::size_t out_size)
{
    if (!value_in || !out || out_size == 0 || !m_print_fmt) {
        return 0;
    }
    return safe_vsnprintf_clamped(out, out_size, m_print_fmt, read_value<T>(value_in));
}

template<typename T>
std::int64_t number_io_c<T>::query_meta(
    const field_desc_s* field_desc,
    std::int64_t a3,
    std::int64_t a4)
{
    return field_io_query_meta(field_desc, a3, a4);
}

template<typename T>
std::int64_t number_io_c<T>::get_default_value(void*)
{
    throw_no_default_value();
}

template<typename T>
std::int64_t default_number_io_c<T>::get_default_value(void* value_out)
{
    if (!value_out) return 0;
    write_value<T>(value_out, m_default_value);
    return static_cast<std::int64_t>(m_default_value);
}

// Constructors via explicit specializations for exact formats
template<> number_io_c<int>::number_io_c() { this->m_print_fmt = "%d";   this->m_scan_fmt = "%d%n"; }
template<> number_io_c<long>::number_io_c() { this->m_print_fmt = "%ld";  this->m_scan_fmt = "%ld%n"; }
template<> number_io_c<unsigned char>::number_io_c() { this->m_print_fmt = "%u";   this->m_scan_fmt = "%hhu%n"; }
template<> number_io_c<float>::number_io_c() { this->m_print_fmt = "%f";   this->m_scan_fmt = "%f%n"; }
template<> number_io_c<double>::number_io_c() { this->m_print_fmt = "%lf";  this->m_scan_fmt = "%lf%n"; }

// IDA-matched wrappers for analyzed int symbols
std::size_t number_io_int_set_from_text(
    std::int64_t self,
    const char** field_desc,
    std::int64_t value_out,
    const char* key,
    const char* text)
{
    auto* obj = reinterpret_cast<number_io_c<int>*>(self);
    return obj->set_from_text(reinterpret_cast<const field_desc_s*>(field_desc), reinterpret_cast<void*>(value_out), key, text);
}

std::size_t number_io_int_get_to_text(
    std::int64_t self,
    std::int64_t a2,
    unsigned int* value_in,
    char* out,
    std::size_t out_size)
{
    auto* obj = reinterpret_cast<number_io_c<int>*>(self);
    return obj->get_to_text(reinterpret_cast<const field_desc_s*>(a2), value_in, out, out_size);
}

std::int64_t default_number_io_int_get_default_value(std::int64_t self, unsigned int* out_value)
{
    auto* obj = reinterpret_cast<default_number_io_c<int>*>(self);
    return obj->get_default_value(out_value);
}

template class number_io_c<int>;
template class number_io_c<long>;
template class number_io_c<unsigned char>;
template class number_io_c<float>;
template class number_io_c<double>;

template class default_number_io_c<int>;
template class default_number_io_c<long>;
template class default_number_io_c<unsigned char>;
template class default_number_io_c<float>;
template class default_number_io_c<double>;

} // namespace __lib_enc_hevc_common__

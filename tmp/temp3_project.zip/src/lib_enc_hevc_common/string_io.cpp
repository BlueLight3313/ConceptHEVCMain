#include "lib_enc_hevc_common/string_io.hpp"

#include <cstring>

namespace __lib_enc_hevc_common__ {

std::int64_t string_io_get_capacity(std::int64_t, std::int64_t a2) // sub_3B4AB0
{
    return *reinterpret_cast<int*>(a2 + 32);
}

std::int64_t string_io_set_from_text(std::int64_t, std::int64_t a2, char* a3, const char* a4, const char* a5) // sub_3B5680
{
    if (std::strcmp(a4, *reinterpret_cast<const char**>(a2)) != 0) {
        return static_cast<std::int64_t>(-1);
    }
    const int cap = *reinterpret_cast<int*>(a2 + 32);
    std::strncpy(a3, a5, static_cast<std::size_t>(cap));
    return static_cast<unsigned int>(cap);
}

std::size_t string_io_get_to_text(std::int64_t, std::int64_t, const char* a3, char* out, std::size_t out_size) // sub_3B4CC0
{
    return safe_vsnprintf_clamped(out, out_size, "%s", a3);
}

std::size_t string_io_c::set_from_text(
    const field_desc_s* field_desc,
    void* value_out,
    const char* key,
    const char* text)
{
    return static_cast<std::size_t>(
        string_io_set_from_text(
            0,
            reinterpret_cast<std::int64_t>(field_desc),
            reinterpret_cast<char*>(value_out),
            key,
            text));
}

std::size_t string_io_c::get_to_text(
    const field_desc_s*,
    const void* value_in,
    char* out,
    std::size_t out_size)
{
    return string_io_get_to_text(0, 0, reinterpret_cast<const char*>(value_in), out, out_size);
}

std::int64_t string_io_c::query_meta(
    const field_desc_s* field_desc,
    std::int64_t a3,
    std::int64_t a4)
{
    return field_io_query_meta(field_desc, a3, a4);
}

std::int64_t string_io_c::get_default_value(void*)
{
    throw_no_default_value();
}

} // namespace __lib_enc_hevc_common__

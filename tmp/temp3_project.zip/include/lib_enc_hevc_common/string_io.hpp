#pragma once

#include "lib_enc_hevc_common/field_io.hpp"

namespace __lib_enc_hevc_common__ {

class string_io_c final : public field_io_i {
public:
    ~string_io_c() override = default;

    std::size_t set_from_text(
        const field_desc_s* field_desc,
        void* value_out,
        const char* key,
        const char* text) override;

    std::size_t get_to_text(
        const field_desc_s* field_desc,
        const void* value_in,
        char* out,
        std::size_t out_size) override;

    std::int64_t query_meta(
        const field_desc_s* field_desc,
        std::int64_t a3,
        std::int64_t a4) override;

    std::int64_t get_default_value(void* value_out) override;
};

// IDA-matched names from analyzed string_io vtable
std::int64_t string_io_get_capacity(std::int64_t a1, std::int64_t a2); // sub_3B4AB0
std::int64_t string_io_set_from_text(std::int64_t a1, std::int64_t a2, char* a3, const char* a4, const char* a5); // sub_3B5680
std::size_t  string_io_get_to_text(std::int64_t a1, std::int64_t a2, const char* a3, char* out, std::size_t out_size); // sub_3B4CC0

} // namespace __lib_enc_hevc_common__

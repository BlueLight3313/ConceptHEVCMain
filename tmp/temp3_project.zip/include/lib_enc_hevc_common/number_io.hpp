#pragma once

#include "lib_enc_hevc_common/field_io.hpp"

#include <cstdint>

namespace __lib_enc_hevc_common__ {

template<typename T>
class number_io_c : public field_io_i {
public:
    virtual ~number_io_c() = default;

    std::size_t set_from_text(
        const field_desc_s* field_desc,
        void* value_out,
        const char* key,
        const char* text) override;

    std::size_t get_to_text(
        const field_desc_s* field_desc,
        const void* value_in,
        char* out,
        std::size_t out_size) override;

    std::int64_t query_meta(
        const field_desc_s* field_desc,
        std::int64_t a3,
        std::int64_t a4) override;

    std::int64_t get_default_value(void* value_out) override;

protected:
    const char* m_print_fmt = nullptr; // observed +0x08
    const char* m_scan_fmt  = nullptr; // observed +0x10
    std::uint32_t m_flags   = 0;       // placeholder/policy flags
};

template<typename T>
class default_number_io_c : public number_io_c<T> {
public:
    ~default_number_io_c() override = default;

    std::int64_t get_default_value(void* value_out) override;

    void set_default(T v) { m_default_value = v; }

protected:
    T m_default_value{}; // observed read near +0x1C on int path
};

// IDA-matched wrappers for analyzed int path
std::size_t number_io_int_set_from_text(
    std::int64_t self,
    const char** field_desc,
    std::int64_t value_out,
    const char* key,
    const char* text);

std::size_t number_io_int_get_to_text(
    std::int64_t self,
    std::int64_t a2,
    unsigned int* value_in,
    char* out,
    std::size_t out_size);

std::int64_t default_number_io_int_get_default_value(std::int64_t self, unsigned int* out_value);

// explicit template declarations
extern template class number_io_c<int>;
extern template class number_io_c<long>;
extern template class number_io_c<unsigned char>;
extern template class number_io_c<float>;
extern template class number_io_c<double>;

extern template class default_number_io_c<int>;
extern template class default_number_io_c<long>;
extern template class default_number_io_c<unsigned char>;
extern template class default_number_io_c<float>;
extern template class default_number_io_c<double>;

} // namespace __lib_enc_hevc_common__

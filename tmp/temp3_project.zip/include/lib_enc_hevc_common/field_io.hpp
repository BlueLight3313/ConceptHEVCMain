#pragma once

#include <cstddef>
#include <cstdint>

namespace __lib_enc_hevc_common__ {

// Offset-oriented descriptor placeholder used by reversed code paths.
struct field_desc_s {
    const char* key;          // +0x00
    const char* alias;        // +0x08
    void*       io;           // +0x10 -> field_io_i*
    std::int32_t elem_size;   // element size for arrays
    std::int32_t array_bytes; // total bytes / max string size (observed near +32 in some paths)
    std::int32_t min_elems;   // minimal element count for arrays (observed near +36)
};

class field_io_i {
public:
    virtual ~field_io_i() = default;

    // vtbl slot 1
    virtual std::size_t set_from_text(
        const field_desc_s* field_desc,
        void* value_out,
        const char* key,
        const char* text) = 0;

    // vtbl slot 2
    virtual std::size_t get_to_text(
        const field_desc_s* field_desc,
        const void* value_in,
        char* out,
        std::size_t out_size) = 0;

    // vtbl slot 3
    virtual std::int64_t query_meta(
        const field_desc_s* field_desc,
        std::int64_t a3,
        std::int64_t a4) = 0;

    // vtbl slot 4
    virtual std::int64_t get_default_value(void* value_out) = 0;
};

// IDA: sub_3B1F80
std::size_t safe_vsnprintf_clamped(char* buffer, std::size_t size, const char* fmt, ...);

// IDA: throw_no_default_value
[[noreturn]] void throw_no_default_value();

// IDA: sub_3B4AA0
std::int64_t field_io_query_meta(
    const field_desc_s* field_desc,
    std::int64_t a3,
    std::int64_t a4);

} // namespace __lib_enc_hevc_common__

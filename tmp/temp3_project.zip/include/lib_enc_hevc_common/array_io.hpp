#pragma once

#include "lib_enc_hevc_common/field_io.hpp"

namespace __lib_enc_hevc_common__ {

class array_io_c final : public field_io_i {
public:
    explicit array_io_c(field_io_i* element_io = nullptr) : m_element_io(element_io) {}
    ~array_io_c() override = default;

    void set_element_io(field_io_i* io) { m_element_io = io; }
    field_io_i* element_io() const { return m_element_io; }

    std::size_t set_from_text(
        const field_desc_s* field_desc,
        void* value_out,
        const char* key,
        const char* text) override;

    std::size_t get_to_text(
        const field_desc_s* field_desc,
        const void* value_in,
        char* out,
        std::size_t out_size) override;

    std::int64_t query_meta(
        const field_desc_s* field_desc,
        std::int64_t a3,
        std::int64_t a4) override;

    std::int64_t get_default_value(void* value_out) override;

private:
    field_io_i* m_element_io = nullptr;
};

// IDA-matched names from analyzed array_io
std::int64_t array_io_get_capacity(std::int64_t a1, std::int64_t a2); // sub_3B4AF0
std::int64_t array_io_set_from_text(void* a1, const char** a2, void* a3, const char* a4, const char* a5); // sub_3B94F0
std::size_t  array_io_get_to_text(std::int64_t a1, std::int64_t a2, std::int64_t a3, char* a4, std::size_t a5); // sub_3B6FD0

} // namespace __lib_enc_hevc_common__

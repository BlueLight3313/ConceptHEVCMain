#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_validation__::profile_arib_c
class profile_arib_t {
public:
    profile_arib_t() = default;
    virtual ~profile_arib_t() = default;
};
} // namespace placeholders

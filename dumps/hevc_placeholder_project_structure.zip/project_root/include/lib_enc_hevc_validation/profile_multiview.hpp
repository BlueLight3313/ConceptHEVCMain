#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_validation__::profile_multiview_c
class profile_multiview_t {
public:
    profile_multiview_t() = default;
    virtual ~profile_multiview_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_validation__::profile_miaf_c
class profile_miaf_t {
public:
    profile_miaf_t() = default;
    virtual ~profile_miaf_t() = default;
};
} // namespace placeholders

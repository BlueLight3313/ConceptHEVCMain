#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_validation__::profile_nv_inque_c
class profile_nv_inque_t {
public:
    profile_nv_inque_t() = default;
    virtual ~profile_nv_inque_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_validation__::profile_enc_hw_c
class profile_enc_hw_t {
public:
    profile_enc_hw_t() = default;
    virtual ~profile_enc_hw_t() = default;
};
} // namespace placeholders

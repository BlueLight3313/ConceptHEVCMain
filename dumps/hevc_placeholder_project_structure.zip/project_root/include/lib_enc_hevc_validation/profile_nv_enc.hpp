#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_validation__::profile_nv_enc_c
class profile_nv_enc_t {
public:
    profile_nv_enc_t() = default;
    virtual ~profile_nv_enc_t() = default;
};
} // namespace placeholders

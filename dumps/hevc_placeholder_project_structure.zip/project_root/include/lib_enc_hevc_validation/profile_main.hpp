#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_validation__::profile_main_c
class profile_main_t {
public:
    profile_main_t() = default;
    virtual ~profile_main_t() = default;
};
} // namespace placeholders

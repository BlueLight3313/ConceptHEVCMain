#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_validation__::profile_base_c
class profile_base_t {
public:
    profile_base_t() = default;
    virtual ~profile_base_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_validation__::profile_atsc_c
class profile_atsc_t {
public:
    profile_atsc_t() = default;
    virtual ~profile_atsc_t() = default;
};
} // namespace placeholders

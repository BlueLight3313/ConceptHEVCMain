#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_validation__::profile_4k_c
class profile_4k_t {
public:
    profile_4k_t() = default;
    virtual ~profile_4k_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_validation__::profile_dvb_c
class profile_dvb_t {
public:
    profile_dvb_t() = default;
    virtual ~profile_dvb_t() = default;
};
} // namespace placeholders

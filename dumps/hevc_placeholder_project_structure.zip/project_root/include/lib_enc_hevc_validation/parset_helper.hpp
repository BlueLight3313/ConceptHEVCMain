#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_validation__::parset_helper_c
class parset_helper_t {
public:
    parset_helper_t() = default;
    virtual ~parset_helper_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_validation__::profile_dash_c
class profile_dash_t {
public:
    profile_dash_t() = default;
    virtual ~profile_dash_t() = default;
};
} // namespace placeholders

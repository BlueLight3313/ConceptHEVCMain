#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_validation__::profile_hls_c
class profile_hls_t {
public:
    profile_hls_t() = default;
    virtual ~profile_hls_t() = default;
};
} // namespace placeholders

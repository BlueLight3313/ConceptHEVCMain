#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_validation__::profile_4k10_c
class profile_4k10_t {
public:
    profile_4k10_t() = default;
    virtual ~profile_4k10_t() = default;
};
} // namespace placeholders

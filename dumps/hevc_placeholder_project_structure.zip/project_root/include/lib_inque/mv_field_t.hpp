#pragma once

namespace placeholders {
// Original placeholder: __lib_inque__::mv_field_t
class mv_field_t_t {
public:
    mv_field_t_t() = default;
    virtual ~mv_field_t_t() = default;
};
} // namespace placeholders

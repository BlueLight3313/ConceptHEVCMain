#pragma once

namespace placeholders {
// Original placeholder: __lib_inque__::downscale_slice_fiber_c
class downscale_slice_fiber_t {
public:
    downscale_slice_fiber_t() = default;
    virtual ~downscale_slice_fiber_t() = default;
};
} // namespace placeholders

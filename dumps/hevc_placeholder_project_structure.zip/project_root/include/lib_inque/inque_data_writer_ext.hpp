#pragma once

namespace placeholders {
// Original placeholder: __lib_inque__::inque_data_writer_ext_c
class inque_data_writer_ext_t {
public:
    inque_data_writer_ext_t() = default;
    virtual ~inque_data_writer_ext_t() = default;
};
} // namespace placeholders

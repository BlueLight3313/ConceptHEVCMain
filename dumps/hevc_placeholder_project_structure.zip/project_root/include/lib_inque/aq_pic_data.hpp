#pragma once

namespace placeholders {
// Original placeholder: __lib_inque__::aq_pic_data_c
class aq_pic_data_t {
public:
    aq_pic_data_t() = default;
    virtual ~aq_pic_data_t() = default;
};
} // namespace placeholders

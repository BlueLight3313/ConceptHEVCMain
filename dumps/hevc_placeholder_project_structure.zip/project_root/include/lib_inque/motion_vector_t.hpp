#pragma once

namespace placeholders {
// Original placeholder: __lib_inque__::field_t<inque::motion_vector_t>
class motion_vector_t_t {
public:
    motion_vector_t_t() = default;
    virtual ~motion_vector_t_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_inque__::spatial_aq_c
class spatial_aq_t {
public:
    spatial_aq_t() = default;
    virtual ~spatial_aq_t() = default;
};
} // namespace placeholders

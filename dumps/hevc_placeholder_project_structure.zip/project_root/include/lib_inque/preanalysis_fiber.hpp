#pragma once

namespace placeholders {
// Original placeholder: __lib_inque__::preanalysis_fiber_c
class preanalysis_fiber_t {
public:
    preanalysis_fiber_t() = default;
    virtual ~preanalysis_fiber_t() = default;
};
} // namespace placeholders

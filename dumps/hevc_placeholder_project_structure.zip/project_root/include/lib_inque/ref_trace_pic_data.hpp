#pragma once

namespace placeholders {
// Original placeholder: __lib_inque__::ref_trace_pic_data_c
class ref_trace_pic_data_t {
public:
    ref_trace_pic_data_t() = default;
    virtual ~ref_trace_pic_data_t() = default;
};
} // namespace placeholders

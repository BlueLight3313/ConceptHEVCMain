#pragma once

namespace placeholders {
// Original placeholder: __lib_inque__::pool_item_c<__lib_inque__::src_frame_c>
class src_frame_3_t {
public:
    src_frame_3_t() = default;
    virtual ~src_frame_3_t() = default;
};
} // namespace placeholders

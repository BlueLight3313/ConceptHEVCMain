#pragma once

namespace placeholders {
// Original placeholder: __lib_inque__::frame_cuda_analysis_fiber_c
class frameuda_analysis_fiber_t {
public:
    frameuda_analysis_fiber_t() = default;
    virtual ~frameuda_analysis_fiber_t() = default;
};
} // namespace placeholders

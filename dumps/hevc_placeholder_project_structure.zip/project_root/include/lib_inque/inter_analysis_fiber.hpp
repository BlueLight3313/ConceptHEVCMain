#pragma once

namespace placeholders {
// Original placeholder: __lib_inque__::inter_analysis_fiber_c
class inter_analysis_fiber_t {
public:
    inter_analysis_fiber_t() = default;
    virtual ~inter_analysis_fiber_t() = default;
};
} // namespace placeholders

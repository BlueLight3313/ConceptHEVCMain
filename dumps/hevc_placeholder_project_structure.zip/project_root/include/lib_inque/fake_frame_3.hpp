#pragma once

namespace placeholders {
// Original placeholder: __lib_inque__::pool_item_c<__lib_inque__::fake_frame_c>
class fake_frame_3_t {
public:
    fake_frame_3_t() = default;
    virtual ~fake_frame_3_t() = default;
};
} // namespace placeholders

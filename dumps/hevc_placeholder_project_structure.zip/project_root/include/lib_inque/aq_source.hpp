#pragma once

namespace placeholders {
// Original placeholder: __lib_inque__::aq_source_c
class aq_source_t {
public:
    aq_source_t() = default;
    virtual ~aq_source_t() = default;
};
} // namespace placeholders

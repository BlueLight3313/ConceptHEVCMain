#pragma once

namespace placeholders {
// Original placeholder: __lib_inque__::src_picture_c
class src_picture_t {
public:
    src_picture_t() = default;
    virtual ~src_picture_t() = default;
};
} // namespace placeholders

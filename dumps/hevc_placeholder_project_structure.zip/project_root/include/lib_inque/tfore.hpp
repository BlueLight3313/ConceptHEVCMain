#pragma once

namespace placeholders {
// Original placeholder: __lib_inque__::tf_core_c
class tfore_t {
public:
    tfore_t() = default;
    virtual ~tfore_t() = default;
};
} // namespace placeholders

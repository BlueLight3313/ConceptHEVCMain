#pragma once

namespace placeholders {
// Original placeholder: __lib_inque__::src_frames_pool_c
class src_frames_pool_t {
public:
    src_frames_pool_t() = default;
    virtual ~src_frames_pool_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_inque__::filter_frame_fiber_c
class filter_frame_fiber_t {
public:
    filter_frame_fiber_t() = default;
    virtual ~filter_frame_fiber_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_inque__::inq_service_c
class inq_service_t {
public:
    inq_service_t() = default;
    virtual ~inq_service_t() = default;
};
} // namespace placeholders

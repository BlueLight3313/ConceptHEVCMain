#pragma once

namespace placeholders {
// Original placeholder: __lib_inque__::ref_tracer_c
class ref_tracer_t {
public:
    ref_tracer_t() = default;
    virtual ~ref_tracer_t() = default;
};
} // namespace placeholders

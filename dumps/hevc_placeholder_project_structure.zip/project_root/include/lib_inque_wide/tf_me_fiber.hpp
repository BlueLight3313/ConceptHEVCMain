#pragma once

namespace placeholders {
// Original placeholder: __lib_inque_wide__::tf_me_fiber_c
class tf_me_fiber_t {
public:
    tf_me_fiber_t() = default;
    virtual ~tf_me_fiber_t() = default;
};
} // namespace placeholders

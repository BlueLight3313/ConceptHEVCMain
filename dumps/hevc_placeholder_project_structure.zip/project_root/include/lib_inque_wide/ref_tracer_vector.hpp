#pragma once

namespace placeholders {
// Original placeholder: __lib_inque_wide__::ref_tracer_vector_c
class ref_tracer_vector_t {
public:
    ref_tracer_vector_t() = default;
    virtual ~ref_tracer_vector_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_inque_wide__::preprocessor_c
class preprocessor_t {
public:
    preprocessor_t() = default;
    virtual ~preprocessor_t() = default;
};
} // namespace placeholders

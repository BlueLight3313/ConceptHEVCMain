#pragma once

namespace placeholders {
// Original placeholder: __lib_inque_wide__::src_queue_c
class src_queue_t {
public:
    src_queue_t() = default;
    virtual ~src_queue_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_inque_wide__::pool_c<__lib_inque_wide__::fake_frame_c>
class fake_frame_t {
public:
    fake_frame_t() = default;
    virtual ~fake_frame_t() = default;
};
} // namespace placeholders

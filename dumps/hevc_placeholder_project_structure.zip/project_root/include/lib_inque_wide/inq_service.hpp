#pragma once

namespace placeholders {
// Original placeholder: __lib_inque_wide__::inq_service_c
class inq_service_t {
public:
    inq_service_t() = default;
    virtual ~inq_service_t() = default;
};
} // namespace placeholders

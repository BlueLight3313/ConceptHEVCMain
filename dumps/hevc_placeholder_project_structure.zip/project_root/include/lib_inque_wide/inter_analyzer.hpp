#pragma once

namespace placeholders {
// Original placeholder: __lib_inque_wide__::inter_analyzer_c
class inter_analyzer_t {
public:
    inter_analyzer_t() = default;
    virtual ~inter_analyzer_t() = default;
};
} // namespace placeholders

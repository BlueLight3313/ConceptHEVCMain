#pragma once

namespace placeholders {
// Original placeholder: __lib_inque_wide__::finalize_frame_analysis_fiber_c
class finalize_frame_analysis_fiber_t {
public:
    finalize_frame_analysis_fiber_t() = default;
    virtual ~finalize_frame_analysis_fiber_t() = default;
};
} // namespace placeholders

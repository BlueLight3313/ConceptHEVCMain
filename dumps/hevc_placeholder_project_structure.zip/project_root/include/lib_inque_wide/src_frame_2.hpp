#pragma once

namespace placeholders {
// Original placeholder: __lib_inque_wide__::src_frame_c
class src_frame_2_t {
public:
    src_frame_2_t() = default;
    virtual ~src_frame_2_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_inque_wide__::inque_control_c
class inqueontrol_t {
public:
    inqueontrol_t() = default;
    virtual ~inqueontrol_t() = default;
};
} // namespace placeholders

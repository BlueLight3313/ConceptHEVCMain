#pragma once

namespace placeholders {
// Original placeholder: __lib_inque_wide__::pre_analyze_one_frame_fiber_c
class pre_analyze_one_frame_fiber_t {
public:
    pre_analyze_one_frame_fiber_t() = default;
    virtual ~pre_analyze_one_frame_fiber_t() = default;
};
} // namespace placeholders

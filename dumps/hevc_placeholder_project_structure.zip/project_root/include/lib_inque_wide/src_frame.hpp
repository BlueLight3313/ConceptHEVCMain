#pragma once

namespace placeholders {
// Original placeholder: __lib_inque_wide__::pool_c<__lib_inque_wide__::src_frame_c>
class src_frame_t {
public:
    src_frame_t() = default;
    virtual ~src_frame_t() = default;
};
} // namespace placeholders

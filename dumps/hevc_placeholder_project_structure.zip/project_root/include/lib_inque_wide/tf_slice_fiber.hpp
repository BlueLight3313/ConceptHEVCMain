#pragma once

namespace placeholders {
// Original placeholder: __lib_inque_wide__::tf_slice_fiber_c
class tf_slice_fiber_t {
public:
    tf_slice_fiber_t() = default;
    virtual ~tf_slice_fiber_t() = default;
};
} // namespace placeholders

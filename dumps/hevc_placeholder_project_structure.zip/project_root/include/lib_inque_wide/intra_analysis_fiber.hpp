#pragma once

namespace placeholders {
// Original placeholder: __lib_inque_wide__::intra_analysis_fiber_c
class intra_analysis_fiber_t {
public:
    intra_analysis_fiber_t() = default;
    virtual ~intra_analysis_fiber_t() = default;
};
} // namespace placeholders

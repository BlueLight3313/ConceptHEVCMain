#pragma once

namespace placeholders {
// Original placeholder: __lib_inque_wide__::external_qp_map_c
class external_qp_map_t {
public:
    external_qp_map_t() = default;
    virtual ~external_qp_map_t() = default;
};
} // namespace placeholders

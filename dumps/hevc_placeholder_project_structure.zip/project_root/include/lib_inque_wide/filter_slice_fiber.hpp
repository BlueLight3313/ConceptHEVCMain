#pragma once

namespace placeholders {
// Original placeholder: __lib_inque_wide__::filter_slice_fiber_c
class filter_slice_fiber_t {
public:
    filter_slice_fiber_t() = default;
    virtual ~filter_slice_fiber_t() = default;
};
} // namespace placeholders

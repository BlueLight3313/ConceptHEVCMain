#pragma once

namespace placeholders {
// Original placeholder: __lib_inque_wide__::unsharp_slice_fiber_c
class unsharp_slice_fiber_t {
public:
    unsharp_slice_fiber_t() = default;
    virtual ~unsharp_slice_fiber_t() = default;
};
} // namespace placeholders

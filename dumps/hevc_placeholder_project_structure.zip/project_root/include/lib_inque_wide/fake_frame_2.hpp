#pragma once

namespace placeholders {
// Original placeholder: __lib_inque_wide__::fake_frame_c
class fake_frame_2_t {
public:
    fake_frame_2_t() = default;
    virtual ~fake_frame_2_t() = default;
};
} // namespace placeholders

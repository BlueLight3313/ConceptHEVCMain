#pragma once

namespace placeholders {
// Original placeholder: __lib_inque_wide__::cuda_picture_layer_c
class cuda_picture_layer_t {
public:
    cuda_picture_layer_t() = default;
    virtual ~cuda_picture_layer_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hw_hevc__::enc_hw_hevc_impl_c
class enc_hw_hevc_impl_t {
public:
    enc_hw_hevc_impl_t() = default;
    virtual ~enc_hw_hevc_impl_t() = default;
};
} // namespace placeholders

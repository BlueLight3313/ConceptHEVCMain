#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hw_hevc__::enc_hw_hevc_impl_c::stat_c
class stat_t {
public:
    stat_t() = default;
    virtual ~stat_t() = default;
};
} // namespace placeholders

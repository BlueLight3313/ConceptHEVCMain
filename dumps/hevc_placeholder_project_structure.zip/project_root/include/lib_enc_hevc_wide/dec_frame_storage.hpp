#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_wide__::dec_frame_storage_c
class dec_frame_storage_t {
public:
    dec_frame_storage_t() = default;
    virtual ~dec_frame_storage_t() = default;
};
} // namespace placeholders

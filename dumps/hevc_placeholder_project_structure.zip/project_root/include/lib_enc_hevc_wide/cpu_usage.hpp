#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_wide__::cpu_usage_c
class cpu_usage_t {
public:
    cpu_usage_t() = default;
    virtual ~cpu_usage_t() = default;
};
} // namespace placeholders

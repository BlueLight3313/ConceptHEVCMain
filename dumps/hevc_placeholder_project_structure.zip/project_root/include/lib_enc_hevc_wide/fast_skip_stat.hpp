#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_wide__::fast_skip_stat_c
class fast_skip_stat_t {
public:
    fast_skip_stat_t() = default;
    virtual ~fast_skip_stat_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_wide__::slice_c
class slice_t {
public:
    slice_t() = default;
    virtual ~slice_t() = default;
};
} // namespace placeholders

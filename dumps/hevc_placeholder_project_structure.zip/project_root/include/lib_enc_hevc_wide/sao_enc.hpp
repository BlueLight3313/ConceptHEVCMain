#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_wide__::sao_enc_c
class sao_enc_t {
public:
    sao_enc_t() = default;
    virtual ~sao_enc_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_wide__::row_postprocessor_c
class row_postprocessor_t {
public:
    row_postprocessor_t() = default;
    virtual ~row_postprocessor_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_wide__::buffer_speed_control_c
class buffer_speedontrol_t {
public:
    buffer_speedontrol_t() = default;
    virtual ~buffer_speedontrol_t() = default;
};
} // namespace placeholders

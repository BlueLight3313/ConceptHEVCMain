#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_wide__::intra_coder_c
class intraoder_t {
public:
    intraoder_t() = default;
    virtual ~intraoder_t() = default;
};
} // namespace placeholders

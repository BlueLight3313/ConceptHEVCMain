#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_wide__::encoder_c
class encoder_t {
public:
    encoder_t() = default;
    virtual ~encoder_t() = default;
};
} // namespace placeholders

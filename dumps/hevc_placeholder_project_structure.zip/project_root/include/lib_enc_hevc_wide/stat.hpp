#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_wide__::stat_c
class stat_t {
public:
    stat_t() = default;
    virtual ~stat_t() = default;
};
} // namespace placeholders

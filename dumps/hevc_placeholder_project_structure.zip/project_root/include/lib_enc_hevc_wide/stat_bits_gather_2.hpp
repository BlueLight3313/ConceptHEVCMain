#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_wide__::entropy_write_c<__lib_enc_hevc_wide__::cabac_coder_c,__lib_enc_hevc_wide__::stat_bits_gather_c>
class stat_bits_gather_2_t {
public:
    stat_bits_gather_2_t() = default;
    virtual ~stat_bits_gather_2_t() = default;
};
} // namespace placeholders

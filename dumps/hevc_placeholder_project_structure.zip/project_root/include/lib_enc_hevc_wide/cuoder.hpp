#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_wide__::cu_coder_c
class cuoder_t {
public:
    cuoder_t() = default;
    virtual ~cuoder_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_wide__::deblock_calculator_c
class deblockalculator_t {
public:
    deblockalculator_t() = default;
    virtual ~deblockalculator_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_wide__::fast_skip_thresholds_c
class fast_skip_thresholds_t {
public:
    fast_skip_thresholds_t() = default;
    virtual ~fast_skip_thresholds_t() = default;
};
} // namespace placeholders

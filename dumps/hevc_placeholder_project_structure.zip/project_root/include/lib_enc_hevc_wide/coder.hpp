#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_wide__::coder_c
class coder_t {
public:
    coder_t() = default;
    virtual ~coder_t() = default;
};
} // namespace placeholders

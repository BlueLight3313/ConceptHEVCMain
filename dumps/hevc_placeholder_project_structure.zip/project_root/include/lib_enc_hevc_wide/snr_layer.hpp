#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_wide__::snr_layer_c
class snr_layer_t {
public:
    snr_layer_t() = default;
    virtual ~snr_layer_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_wide__::bit_counter_full_c<__lib_enc_hevc_wide__::cabac_counter_c,__lib_enc_hevc_wide__::stat_bits_dummy_c>
class stat_bits_dummy_t {
public:
    stat_bits_dummy_t() = default;
    virtual ~stat_bits_dummy_t() = default;
};
} // namespace placeholders

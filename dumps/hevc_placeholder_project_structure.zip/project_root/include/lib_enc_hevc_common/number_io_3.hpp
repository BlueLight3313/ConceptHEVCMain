#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_common__::number_io_c<uchar>
class number_io_3_t {
public:
    number_io_3_t() = default;
    virtual ~number_io_3_t() = default;
};
} // namespace placeholders

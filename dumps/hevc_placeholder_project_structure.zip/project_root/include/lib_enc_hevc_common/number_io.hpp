#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_common__::number_io_c<int>
class number_io_t {
public:
    number_io_t() = default;
    virtual ~number_io_t() = default;
};
} // namespace placeholders

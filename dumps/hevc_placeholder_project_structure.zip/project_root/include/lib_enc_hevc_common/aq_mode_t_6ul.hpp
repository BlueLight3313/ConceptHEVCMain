#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_common__::enum_io_c<mc_enc_hevc_aq_mode_t,inque::aq_mode_t,6ul>
class aq_mode_t_6ul_t {
public:
    aq_mode_t_6ul_t() = default;
    virtual ~aq_mode_t_6ul_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_common__::enum_io_c<mc_enc_hevc_qp_scheme_t,__lib_rc__::qp_scheme_t,3ul>
class qp_scheme_t_3ul_t {
public:
    qp_scheme_t_3ul_t() = default;
    virtual ~qp_scheme_t_3ul_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_common__::enum_io_c<mc_enc_hevc_rc_mode_t,__lib_rc__::rc_mode_t,5ul>
class rc_mode_t_5ul_t {
public:
    rc_mode_t_5ul_t() = default;
    virtual ~rc_mode_t_5ul_t() = default;
};
} // namespace placeholders

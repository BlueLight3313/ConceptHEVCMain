#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_common__::enum_io_c<mc_enc_hevc_hrd_conformance_t,__lib_rc__::hrd_mode_t,3ul>
class hrd_mode_t_3ul_t {
public:
    hrd_mode_t_3ul_t() = default;
    virtual ~hrd_mode_t_3ul_t() = default;
};
} // namespace placeholders

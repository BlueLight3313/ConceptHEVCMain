#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_common__::enum_io_c<mc_enc_hevc_profile_t,profile_t,8ul>
class enum_io_t {
public:
    enum_io_t() = default;
    virtual ~enum_io_t() = default;
};
} // namespace placeholders

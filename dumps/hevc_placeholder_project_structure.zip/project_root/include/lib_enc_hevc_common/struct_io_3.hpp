#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_common__::struct_io_c<mc_display_metadata_t>
class struct_io_3_t {
public:
    struct_io_3_t() = default;
    virtual ~struct_io_3_t() = default;
};
} // namespace placeholders

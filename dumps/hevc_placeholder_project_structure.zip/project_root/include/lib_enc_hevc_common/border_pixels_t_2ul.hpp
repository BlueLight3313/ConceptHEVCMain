#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_common__::enum_io_c<mc_enc_hevc_border_t,inque::border_pixels_t,2ul>
class border_pixels_t_2ul_t {
public:
    border_pixels_t_2ul_t() = default;
    virtual ~border_pixels_t_2ul_t() = default;
};
} // namespace placeholders

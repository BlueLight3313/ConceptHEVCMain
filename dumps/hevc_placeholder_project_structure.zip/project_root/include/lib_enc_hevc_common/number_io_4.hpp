#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_common__::number_io_c<float>
class number_io_4_t {
public:
    number_io_4_t() = default;
    virtual ~number_io_4_t() = default;
};
} // namespace placeholders

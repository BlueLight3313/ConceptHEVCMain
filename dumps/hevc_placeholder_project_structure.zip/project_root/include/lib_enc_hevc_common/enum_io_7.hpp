#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_common__::enum_io_c<mc_enc_hevc_inq_numa_node_t,hevc_numanode_t,2ul>
class enum_io_7_t {
public:
    enum_io_7_t() = default;
    virtual ~enum_io_7_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_common__::enum_io_c<mc_enc_hevc_inq_acceleration_t,inque::inq_acceleration_t,2ul>
class inq_acceleration_t_2ul_t {
public:
    inq_acceleration_t_2ul_t() = default;
    virtual ~inq_acceleration_t_2ul_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_common__::string_io_c
class string_io_t {
public:
    string_io_t() = default;
    virtual ~string_io_t() = default;
};
} // namespace placeholders

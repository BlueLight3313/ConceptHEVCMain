#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_common__::struct_io_c<mc_colorimetry_t>
class struct_io_2_t {
public:
    struct_io_2_t() = default;
    virtual ~struct_io_2_t() = default;
};
} // namespace placeholders

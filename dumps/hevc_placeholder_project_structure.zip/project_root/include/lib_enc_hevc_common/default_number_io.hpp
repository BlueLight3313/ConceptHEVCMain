#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_common__::default_number_io_c<int>
class default_number_io_t {
public:
    default_number_io_t() = default;
    virtual ~default_number_io_t() = default;
};
} // namespace placeholders

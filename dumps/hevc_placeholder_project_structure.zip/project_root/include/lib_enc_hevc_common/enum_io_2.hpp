#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_common__::enum_io_c<mc_enc_hevc_level_t,level_e,15ul>
class enum_io_2_t {
public:
    enum_io_2_t() = default;
    virtual ~enum_io_2_t() = default;
};
} // namespace placeholders

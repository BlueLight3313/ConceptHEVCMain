#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_common__::enum_io_c<mc_enc_hevc_cpb_units_t,__lib_rc__::cpb_units_t,3ul>
class cpb_units_t_3ul_t {
public:
    cpb_units_t_3ul_t() = default;
    virtual ~cpb_units_t_3ul_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_common__::number_io_c<double>
class number_io_5_t {
public:
    number_io_5_t() = default;
    virtual ~number_io_5_t() = default;
};
} // namespace placeholders

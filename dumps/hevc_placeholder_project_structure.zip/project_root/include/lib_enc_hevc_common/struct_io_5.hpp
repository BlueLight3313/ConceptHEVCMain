#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_common__::struct_io_c<settings_s>
class struct_io_5_t {
public:
    struct_io_5_t() = default;
    virtual ~struct_io_5_t() = default;
};
} // namespace placeholders

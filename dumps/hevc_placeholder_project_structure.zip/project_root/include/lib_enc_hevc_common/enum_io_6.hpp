#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_common__::enum_io_c<mc_enc_acceleration_mode_t,hw_acc_mode_t,3ul>
class enum_io_6_t {
public:
    enum_io_6_t() = default;
    virtual ~enum_io_6_t() = default;
};
} // namespace placeholders

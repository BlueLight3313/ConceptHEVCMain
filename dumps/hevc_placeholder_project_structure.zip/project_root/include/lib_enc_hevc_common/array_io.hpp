#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_common__::array_io_c
class array_io_t {
public:
    array_io_t() = default;
    virtual ~array_io_t() = default;
};
} // namespace placeholders

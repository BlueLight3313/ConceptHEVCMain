#pragma once

namespace placeholders {
// Original placeholder: __lib_rc__::pass1_size_predictor_c<__lib_rc__::cmplx_linear_size_predictor_1d>
class cmplx_linear_size_predictor_1d_t {
public:
    cmplx_linear_size_predictor_1d_t() = default;
    virtual ~cmplx_linear_size_predictor_1d_t() = default;
};
} // namespace placeholders

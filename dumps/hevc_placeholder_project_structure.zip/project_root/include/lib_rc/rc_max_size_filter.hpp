#pragma once

namespace placeholders {
// Original placeholder: __lib_rc__::rc_max_size_filter_c
class rc_max_size_filter_t {
public:
    rc_max_size_filter_t() = default;
    virtual ~rc_max_size_filter_t() = default;
};
} // namespace placeholders

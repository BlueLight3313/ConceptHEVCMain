#pragma once

namespace placeholders {
// Original placeholder: __lib_rc__::qp_scheme_const_c
class qp_schemeonst_t {
public:
    qp_schemeonst_t() = default;
    virtual ~qp_schemeonst_t() = default;
};
} // namespace placeholders

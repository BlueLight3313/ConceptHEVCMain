#pragma once

namespace placeholders {
// Original placeholder: __lib_rc__::rc_stat_t
class rc_stat_t_t {
public:
    rc_stat_t_t() = default;
    virtual ~rc_stat_t_t() = default;
};
} // namespace placeholders

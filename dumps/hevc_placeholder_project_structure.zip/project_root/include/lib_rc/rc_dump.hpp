#pragma once

namespace placeholders {
// Original placeholder: __lib_rc__::rc_dump_c
class rc_dump_t {
public:
    rc_dump_t() = default;
    virtual ~rc_dump_t() = default;
};
} // namespace placeholders

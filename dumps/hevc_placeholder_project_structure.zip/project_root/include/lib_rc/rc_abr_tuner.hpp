#pragma once

namespace placeholders {
// Original placeholder: __lib_rc__::rc_abr_tuner_c
class rc_abr_tuner_t {
public:
    rc_abr_tuner_t() = default;
    virtual ~rc_abr_tuner_t() = default;
};
} // namespace placeholders

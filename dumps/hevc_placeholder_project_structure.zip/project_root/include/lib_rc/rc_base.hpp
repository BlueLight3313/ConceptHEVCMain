#pragma once

namespace placeholders {
// Original placeholder: __lib_rc__::rc_base_c
class rc_base_t {
public:
    rc_base_t() = default;
    virtual ~rc_base_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_rc__::rc_low_lat_tuner_c
class rc_low_lat_tuner_t {
public:
    rc_low_lat_tuner_t() = default;
    virtual ~rc_low_lat_tuner_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_rc__::pass1_frame_sequence_c
class pass1_frame_sequence_t {
public:
    pass1_frame_sequence_t() = default;
    virtual ~pass1_frame_sequence_t() = default;
};
} // namespace placeholders

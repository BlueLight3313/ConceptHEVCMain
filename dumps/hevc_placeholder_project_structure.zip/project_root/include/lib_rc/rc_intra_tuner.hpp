#pragma once

namespace placeholders {
// Original placeholder: __lib_rc__::rc_intra_tuner_c
class rc_intra_tuner_t {
public:
    rc_intra_tuner_t() = default;
    virtual ~rc_intra_tuner_t() = default;
};
} // namespace placeholders

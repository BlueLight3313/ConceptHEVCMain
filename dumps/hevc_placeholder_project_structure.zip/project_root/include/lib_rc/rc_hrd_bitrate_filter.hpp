#pragma once

namespace placeholders {
// Original placeholder: __lib_rc__::rc_hrd_bitrate_filter_c
class rc_hrd_bitrate_filter_t {
public:
    rc_hrd_bitrate_filter_t() = default;
    virtual ~rc_hrd_bitrate_filter_t() = default;
};
} // namespace placeholders

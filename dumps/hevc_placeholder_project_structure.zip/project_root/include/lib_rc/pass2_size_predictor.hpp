#pragma once

namespace placeholders {
// Original placeholder: __lib_rc__::pass2_size_predictor_c
class pass2_size_predictor_t {
public:
    pass2_size_predictor_t() = default;
    virtual ~pass2_size_predictor_t() = default;
};
} // namespace placeholders

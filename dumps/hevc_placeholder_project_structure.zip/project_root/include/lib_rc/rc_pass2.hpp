#pragma once

namespace placeholders {
// Original placeholder: __lib_rc__::rc_pass2_c
class rc_pass2_t {
public:
    rc_pass2_t() = default;
    virtual ~rc_pass2_t() = default;
};
} // namespace placeholders

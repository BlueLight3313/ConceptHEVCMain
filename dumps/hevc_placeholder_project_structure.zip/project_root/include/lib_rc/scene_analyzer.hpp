#pragma once

namespace placeholders {
// Original placeholder: __lib_rc__::scene_analyzer_c
class scene_analyzer_t {
public:
    scene_analyzer_t() = default;
    virtual ~scene_analyzer_t() = default;
};
} // namespace placeholders

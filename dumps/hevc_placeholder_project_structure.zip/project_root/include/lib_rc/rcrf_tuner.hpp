#pragma once

namespace placeholders {
// Original placeholder: __lib_rc__::rc_crf_tuner_c
class rcrf_tuner_t {
public:
    rcrf_tuner_t() = default;
    virtual ~rcrf_tuner_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_rc__::qp_scheme_fixed_c
class qp_scheme_fixed_t {
public:
    qp_scheme_fixed_t() = default;
    virtual ~qp_scheme_fixed_t() = default;
};
} // namespace placeholders

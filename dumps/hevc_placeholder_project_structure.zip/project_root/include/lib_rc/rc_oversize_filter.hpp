#pragma once

namespace placeholders {
// Original placeholder: __lib_rc__::rc_oversize_filter_c
class rc_oversize_filter_t {
public:
    rc_oversize_filter_t() = default;
    virtual ~rc_oversize_filter_t() = default;
};
} // namespace placeholders

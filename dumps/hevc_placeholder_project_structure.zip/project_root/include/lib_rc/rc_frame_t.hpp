#pragma once

namespace placeholders {
// Original placeholder: __lib_rc__::sliding_window<__lib_rc__::rc_frame_t>
class rc_frame_t_t {
public:
    rc_frame_t_t() = default;
    virtual ~rc_frame_t_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_rc__::rc_env_member_c
class rc_env_member_t {
public:
    rc_env_member_t() = default;
    virtual ~rc_env_member_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_rc__::rc_pass1_c
class rc_pass1_t {
public:
    rc_pass1_t() = default;
    virtual ~rc_pass1_t() = default;
};
} // namespace placeholders

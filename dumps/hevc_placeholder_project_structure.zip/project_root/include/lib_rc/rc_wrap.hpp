#pragma once

namespace placeholders {
// Original placeholder: __lib_rc__::rc_wrap_c
class rc_wrap_t {
public:
    rc_wrap_t() = default;
    virtual ~rc_wrap_t() = default;
};
} // namespace placeholders

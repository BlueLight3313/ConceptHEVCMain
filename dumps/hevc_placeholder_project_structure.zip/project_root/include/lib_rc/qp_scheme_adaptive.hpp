#pragma once

namespace placeholders {
// Original placeholder: __lib_rc__::qp_scheme_adaptive_c
class qp_scheme_adaptive_t {
public:
    qp_scheme_adaptive_t() = default;
    virtual ~qp_scheme_adaptive_t() = default;
};
} // namespace placeholders

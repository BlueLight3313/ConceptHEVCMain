#pragma once

namespace placeholders {
// Original placeholder: __lib_rc__::rc_load_c
class rc_load_t {
public:
    rc_load_t() = default;
    virtual ~rc_load_t() = default;
};
} // namespace placeholders

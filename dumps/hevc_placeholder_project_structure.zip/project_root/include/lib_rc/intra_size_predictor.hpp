#pragma once

namespace placeholders {
// Original placeholder: __lib_rc__::intra_size_predictor_c
class intra_size_predictor_t {
public:
    intra_size_predictor_t() = default;
    virtual ~intra_size_predictor_t() = default;
};
} // namespace placeholders

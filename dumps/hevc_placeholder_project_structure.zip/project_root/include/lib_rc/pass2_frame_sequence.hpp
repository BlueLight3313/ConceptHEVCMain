#pragma once

namespace placeholders {
// Original placeholder: __lib_rc__::pass2_frame_sequence_c
class pass2_frame_sequence_t {
public:
    pass2_frame_sequence_t() = default;
    virtual ~pass2_frame_sequence_t() = default;
};
} // namespace placeholders

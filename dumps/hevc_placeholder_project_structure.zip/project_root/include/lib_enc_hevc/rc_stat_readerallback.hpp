#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc__::rc_stat_reader_callback_c
class rc_stat_readerallback_t {
public:
    rc_stat_readerallback_t() = default;
    virtual ~rc_stat_readerallback_t() = default;
};
} // namespace placeholders

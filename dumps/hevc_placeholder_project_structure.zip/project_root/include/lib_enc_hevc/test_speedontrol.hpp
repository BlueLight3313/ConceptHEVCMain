#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc__::test_speed_control_c
class test_speedontrol_t {
public:
    test_speedontrol_t() = default;
    virtual ~test_speedontrol_t() = default;
};
} // namespace placeholders

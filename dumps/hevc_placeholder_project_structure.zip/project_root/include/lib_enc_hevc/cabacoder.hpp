#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc__::cabac_coder_c
class cabacoder_t {
public:
    cabacoder_t() = default;
    virtual ~cabacoder_t() = default;
};
} // namespace placeholders

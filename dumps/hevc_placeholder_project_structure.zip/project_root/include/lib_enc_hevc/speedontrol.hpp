#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc__::speed_control_c
class speedontrol_t {
public:
    speedontrol_t() = default;
    virtual ~speedontrol_t() = default;
};
} // namespace placeholders

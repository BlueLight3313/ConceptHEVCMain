#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc__::rc_stat_writer_callback_c
class rc_stat_writerallback_t {
public:
    rc_stat_writerallback_t() = default;
    virtual ~rc_stat_writerallback_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc__::bit_counter_full_c<__lib_enc_hevc__::cabac_counter_c,__lib_enc_hevc__::stat_bits_dummy_c>
class stat_bits_dummy_t {
public:
    stat_bits_dummy_t() = default;
    virtual ~stat_bits_dummy_t() = default;
};
} // namespace placeholders

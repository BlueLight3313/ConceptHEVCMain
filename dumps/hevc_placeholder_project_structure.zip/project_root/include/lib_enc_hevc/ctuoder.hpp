#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc__::ctu_coder_c
class ctuoder_t {
public:
    ctuoder_t() = default;
    virtual ~ctuoder_t() = default;
};
} // namespace placeholders

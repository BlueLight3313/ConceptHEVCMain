#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc__::cabac_counter_c
class cabacounter_t {
public:
    cabacounter_t() = default;
    virtual ~cabacounter_t() = default;
};
} // namespace placeholders

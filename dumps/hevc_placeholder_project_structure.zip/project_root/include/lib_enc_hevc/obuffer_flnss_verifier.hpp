#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc__::encoder_c::obuffer_flnss_verifier_c
class obuffer_flnss_verifier_t {
public:
    obuffer_flnss_verifier_t() = default;
    virtual ~obuffer_flnss_verifier_t() = default;
};
} // namespace placeholders

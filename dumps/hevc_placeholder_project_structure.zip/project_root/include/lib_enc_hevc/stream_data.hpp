#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc__::stream_data_c
class stream_data_t {
public:
    stream_data_t() = default;
    virtual ~stream_data_t() = default;
};
} // namespace placeholders

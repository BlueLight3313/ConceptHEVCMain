#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc__::rc_stream_c
class rc_stream_t {
public:
    rc_stream_t() = default;
    virtual ~rc_stream_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc__::statistic_manager_c
class statistic_manager_t {
public:
    statistic_manager_t() = default;
    virtual ~statistic_manager_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc__::inter_coder_c
class interoder_t {
public:
    interoder_t() = default;
    virtual ~interoder_t() = default;
};
} // namespace placeholders

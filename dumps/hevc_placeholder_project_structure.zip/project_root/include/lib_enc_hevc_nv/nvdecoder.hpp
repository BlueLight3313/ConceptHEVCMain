#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_nv__::NvDecoder
class nvdecoder_t {
public:
    nvdecoder_t() = default;
    virtual ~nvdecoder_t() = default;
};
} // namespace placeholders

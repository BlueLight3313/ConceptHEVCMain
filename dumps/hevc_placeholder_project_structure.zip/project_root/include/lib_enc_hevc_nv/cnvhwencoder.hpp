#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_nv__::CNvHWEncoder
class cnvhwencoder_t {
public:
    cnvhwencoder_t() = default;
    virtual ~cnvhwencoder_t() = default;
};
} // namespace placeholders

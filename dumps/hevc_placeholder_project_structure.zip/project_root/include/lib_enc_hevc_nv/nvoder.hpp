#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_nv__::nv_coder_c
class nvoder_t {
public:
    nvoder_t() = default;
    virtual ~nvoder_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_nv__::nv_transfer_helper_c
class nv_transfer_helper_t {
public:
    nv_transfer_helper_t() = default;
    virtual ~nv_transfer_helper_t() = default;
};
} // namespace placeholders

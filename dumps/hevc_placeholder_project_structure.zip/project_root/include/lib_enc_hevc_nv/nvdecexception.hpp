#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_nv__::NVDECException
class nvdecexception_t {
public:
    nvdecexception_t() = default;
    virtual ~nvdecexception_t() = default;
};
} // namespace placeholders

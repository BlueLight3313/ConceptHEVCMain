#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_nv__::NvEncoderCustom
class nvencodercustom_t {
public:
    nvencodercustom_t() = default;
    virtual ~nvencodercustom_t() = default;
};
} // namespace placeholders

#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_nv__::NvEncoderCuda
class nvencodercuda_t {
public:
    nvencodercuda_t() = default;
    virtual ~nvencodercuda_t() = default;
};
} // namespace placeholders

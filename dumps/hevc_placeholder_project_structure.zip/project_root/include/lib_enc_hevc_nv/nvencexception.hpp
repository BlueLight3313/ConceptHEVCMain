#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_nv__::NVENCException
class nvencexception_t {
public:
    nvencexception_t() = default;
    virtual ~nvencexception_t() = default;
};
} // namespace placeholders

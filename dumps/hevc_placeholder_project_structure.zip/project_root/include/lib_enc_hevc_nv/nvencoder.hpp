#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_nv__::NvEncoder
class nvencoder_t {
public:
    nvencoder_t() = default;
    virtual ~nvencoder_t() = default;
};
} // namespace placeholders

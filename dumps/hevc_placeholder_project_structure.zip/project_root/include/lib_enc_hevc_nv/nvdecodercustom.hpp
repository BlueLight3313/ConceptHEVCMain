#pragma once

namespace placeholders {
// Original placeholder: __lib_enc_hevc_nv__::NvDecoderCustom
class nvdecodercustom_t {
public:
    nvdecodercustom_t() = default;
    virtual ~nvdecodercustom_t() = default;
};
} // namespace placeholders

#include "lib_inque/picture_analysis_fiber.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::picture_analysis_fiber_c
} // namespace placeholders

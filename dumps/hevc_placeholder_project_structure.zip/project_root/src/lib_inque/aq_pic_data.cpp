#include "lib_inque/aq_pic_data.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::aq_pic_data_c
} // namespace placeholders

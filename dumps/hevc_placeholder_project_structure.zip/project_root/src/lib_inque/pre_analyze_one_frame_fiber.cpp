#include "lib_inque/pre_analyze_one_frame_fiber.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::pre_analyze_one_frame_fiber_c
} // namespace placeholders

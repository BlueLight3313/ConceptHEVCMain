#include "lib_inque/src_frame_3.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::pool_item_c<__lib_inque__::src_frame_c>
} // namespace placeholders

#include "lib_inque/spatial_aq.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::spatial_aq_c
} // namespace placeholders

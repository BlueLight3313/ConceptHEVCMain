#include "lib_inque/frameuda_analysis_fiber.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::frame_cuda_analysis_fiber_c
} // namespace placeholders

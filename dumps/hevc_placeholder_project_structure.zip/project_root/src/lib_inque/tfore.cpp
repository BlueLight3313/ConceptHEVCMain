#include "lib_inque/tfore.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::tf_core_c
} // namespace placeholders

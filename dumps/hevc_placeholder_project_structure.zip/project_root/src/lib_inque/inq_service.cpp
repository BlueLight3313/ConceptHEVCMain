#include "lib_inque/inq_service.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::inq_service_c
} // namespace placeholders

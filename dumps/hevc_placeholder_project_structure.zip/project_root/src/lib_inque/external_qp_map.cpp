#include "lib_inque/external_qp_map.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::external_qp_map_c
} // namespace placeholders

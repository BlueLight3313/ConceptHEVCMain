#include "lib_inque/sc_analysis_fiber.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::sc_analysis_fiber_c
} // namespace placeholders

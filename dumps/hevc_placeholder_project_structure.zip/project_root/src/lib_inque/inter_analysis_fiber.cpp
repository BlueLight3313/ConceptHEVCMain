#include "lib_inque/inter_analysis_fiber.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::inter_analysis_fiber_c
} // namespace placeholders

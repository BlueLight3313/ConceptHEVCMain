#include "lib_inque/inqueontrol.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::inque_control_c
} // namespace placeholders

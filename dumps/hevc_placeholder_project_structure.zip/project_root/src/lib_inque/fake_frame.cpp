#include "lib_inque/fake_frame.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::pool_c<__lib_inque__::fake_frame_c>
} // namespace placeholders

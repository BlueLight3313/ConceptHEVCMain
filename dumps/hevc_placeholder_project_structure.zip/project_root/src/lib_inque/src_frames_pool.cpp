#include "lib_inque/src_frames_pool.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::src_frames_pool_c
} // namespace placeholders

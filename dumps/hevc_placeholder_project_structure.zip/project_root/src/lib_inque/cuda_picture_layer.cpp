#include "lib_inque/cuda_picture_layer.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::cuda_picture_layer_c
} // namespace placeholders

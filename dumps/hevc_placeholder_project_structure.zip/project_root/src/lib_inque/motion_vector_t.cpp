#include "lib_inque/motion_vector_t.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::field_t<inque::motion_vector_t>
} // namespace placeholders

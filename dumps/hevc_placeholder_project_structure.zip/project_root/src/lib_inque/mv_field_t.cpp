#include "lib_inque/mv_field_t.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::mv_field_t
} // namespace placeholders

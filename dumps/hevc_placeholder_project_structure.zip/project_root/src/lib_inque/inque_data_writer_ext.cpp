#include "lib_inque/inque_data_writer_ext.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::inque_data_writer_ext_c
} // namespace placeholders

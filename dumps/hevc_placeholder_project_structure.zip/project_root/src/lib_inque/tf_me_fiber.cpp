#include "lib_inque/tf_me_fiber.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::tf_me_fiber_c
} // namespace placeholders

#include "lib_inque/preanalysis_fiber.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::preanalysis_fiber_c
} // namespace placeholders

#include "lib_inque/src_picture.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::src_picture_c
} // namespace placeholders

#include "lib_inque/filter_frame_fiber.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::filter_frame_fiber_c
} // namespace placeholders

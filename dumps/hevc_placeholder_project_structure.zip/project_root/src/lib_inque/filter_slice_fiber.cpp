#include "lib_inque/filter_slice_fiber.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::filter_slice_fiber_c
} // namespace placeholders

#include "lib_inque/fake_frame_2.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::fake_frame_c
} // namespace placeholders

#include "lib_inque/ref_trace_pic_data.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::ref_trace_pic_data_c
} // namespace placeholders

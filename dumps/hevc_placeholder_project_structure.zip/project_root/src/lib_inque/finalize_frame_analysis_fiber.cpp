#include "lib_inque/finalize_frame_analysis_fiber.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::finalize_frame_analysis_fiber_c
} // namespace placeholders

#include "lib_inque/src_frame_2.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::src_frame_c
} // namespace placeholders

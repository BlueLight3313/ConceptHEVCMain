#include "lib_inque/aq_source.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::aq_source_c
} // namespace placeholders

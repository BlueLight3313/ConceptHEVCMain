#include "lib_inque/preprocessor.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::preprocessor_c
} // namespace placeholders

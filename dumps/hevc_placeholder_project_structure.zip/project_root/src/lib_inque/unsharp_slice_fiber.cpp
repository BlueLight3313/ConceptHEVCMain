#include "lib_inque/unsharp_slice_fiber.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::unsharp_slice_fiber_c
} // namespace placeholders

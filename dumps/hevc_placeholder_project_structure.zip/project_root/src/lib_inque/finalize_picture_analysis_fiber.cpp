#include "lib_inque/finalize_picture_analysis_fiber.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::finalize_picture_analysis_fiber_c
} // namespace placeholders

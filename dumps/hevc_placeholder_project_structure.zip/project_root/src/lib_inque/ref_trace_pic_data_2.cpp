#include "lib_inque/ref_trace_pic_data_2.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::ref_tracer_vector_c::ref_trace_pic_data_c
} // namespace placeholders

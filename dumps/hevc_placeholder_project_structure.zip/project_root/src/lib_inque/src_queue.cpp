#include "lib_inque/src_queue.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::src_queue_c
} // namespace placeholders

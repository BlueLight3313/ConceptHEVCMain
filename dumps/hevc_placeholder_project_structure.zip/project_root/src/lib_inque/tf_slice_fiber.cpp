#include "lib_inque/tf_slice_fiber.hpp"

namespace placeholders {
// Translation unit for: __lib_inque__::tf_slice_fiber_c
} // namespace placeholders

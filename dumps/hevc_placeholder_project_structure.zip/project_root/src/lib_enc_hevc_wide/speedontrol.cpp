#include "lib_enc_hevc_wide/speedontrol.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_wide__::speed_control_c
} // namespace placeholders

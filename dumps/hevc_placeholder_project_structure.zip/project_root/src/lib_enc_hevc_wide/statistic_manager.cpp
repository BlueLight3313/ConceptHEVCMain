#include "lib_enc_hevc_wide/statistic_manager.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_wide__::statistic_manager_c
} // namespace placeholders

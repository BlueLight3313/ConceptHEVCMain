#include "lib_enc_hevc_wide/stat_bits_gather_2.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_wide__::entropy_write_c<__lib_enc_hevc_wide__::cabac_coder_c,__lib_enc_hevc_wide__::stat_bits_gather_c>
} // namespace placeholders

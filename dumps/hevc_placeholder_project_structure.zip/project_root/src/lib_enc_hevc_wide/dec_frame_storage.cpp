#include "lib_enc_hevc_wide/dec_frame_storage.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_wide__::dec_frame_storage_c
} // namespace placeholders

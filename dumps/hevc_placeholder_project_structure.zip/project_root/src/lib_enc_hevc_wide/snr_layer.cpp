#include "lib_enc_hevc_wide/snr_layer.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_wide__::snr_layer_c
} // namespace placeholders

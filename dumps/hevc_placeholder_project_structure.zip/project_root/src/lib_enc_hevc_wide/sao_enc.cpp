#include "lib_enc_hevc_wide/sao_enc.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_wide__::sao_enc_c
} // namespace placeholders

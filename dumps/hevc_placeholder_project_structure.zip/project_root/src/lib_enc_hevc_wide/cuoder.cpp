#include "lib_enc_hevc_wide/cuoder.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_wide__::cu_coder_c
} // namespace placeholders

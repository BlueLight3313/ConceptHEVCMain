#include "lib_enc_hevc_wide/rc_stat_writerallback.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_wide__::rc_stat_writer_callback_c
} // namespace placeholders

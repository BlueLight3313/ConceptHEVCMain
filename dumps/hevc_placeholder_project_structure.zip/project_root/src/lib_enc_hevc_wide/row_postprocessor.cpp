#include "lib_enc_hevc_wide/row_postprocessor.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_wide__::row_postprocessor_c
} // namespace placeholders

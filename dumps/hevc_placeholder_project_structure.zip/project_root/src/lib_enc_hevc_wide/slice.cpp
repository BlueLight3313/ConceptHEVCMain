#include "lib_enc_hevc_wide/slice.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_wide__::slice_c
} // namespace placeholders

#include "lib_enc_hevc_wide/deblockalculator.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_wide__::deblock_calculator_c
} // namespace placeholders

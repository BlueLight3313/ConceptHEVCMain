#include "lib_enc_hevc_wide/fast_skip_thresholds.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_wide__::fast_skip_thresholds_c
} // namespace placeholders

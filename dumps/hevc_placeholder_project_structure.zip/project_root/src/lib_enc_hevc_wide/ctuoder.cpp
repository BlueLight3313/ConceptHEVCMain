#include "lib_enc_hevc_wide/ctuoder.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_wide__::ctu_coder_c
} // namespace placeholders

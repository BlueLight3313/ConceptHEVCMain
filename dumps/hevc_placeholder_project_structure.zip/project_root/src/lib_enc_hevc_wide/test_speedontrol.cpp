#include "lib_enc_hevc_wide/test_speedontrol.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_wide__::test_speed_control_c
} // namespace placeholders

#include "lib_enc_hevc_wide/stat_bits_dummy.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_wide__::bit_counter_full_c<__lib_enc_hevc_wide__::cabac_counter_c,__lib_enc_hevc_wide__::stat_bits_dummy_c>
} // namespace placeholders

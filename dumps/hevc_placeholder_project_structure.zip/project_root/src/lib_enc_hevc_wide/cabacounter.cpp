#include "lib_enc_hevc_wide/cabacounter.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_wide__::cabac_counter_c
} // namespace placeholders

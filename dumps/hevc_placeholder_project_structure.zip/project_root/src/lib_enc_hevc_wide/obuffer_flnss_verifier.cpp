#include "lib_enc_hevc_wide/obuffer_flnss_verifier.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_wide__::encoder_c::obuffer_flnss_verifier_c
} // namespace placeholders

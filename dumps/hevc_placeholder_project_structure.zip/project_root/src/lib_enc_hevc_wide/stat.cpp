#include "lib_enc_hevc_wide/stat.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_wide__::stat_c
} // namespace placeholders

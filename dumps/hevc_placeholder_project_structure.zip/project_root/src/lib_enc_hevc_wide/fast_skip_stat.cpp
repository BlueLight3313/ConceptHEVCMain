#include "lib_enc_hevc_wide/fast_skip_stat.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_wide__::fast_skip_stat_c
} // namespace placeholders

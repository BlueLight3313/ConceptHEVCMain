#include "lib_enc_hevc_wide/buffer_speedontrol.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_wide__::buffer_speed_control_c
} // namespace placeholders

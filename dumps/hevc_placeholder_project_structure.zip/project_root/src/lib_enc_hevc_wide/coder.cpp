#include "lib_enc_hevc_wide/coder.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_wide__::coder_c
} // namespace placeholders

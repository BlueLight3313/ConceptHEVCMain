#include "lib_enc_hevc_wide/cpu_usage.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_wide__::cpu_usage_c
} // namespace placeholders

#include "lib_enc_hevc_wide/rc_stream.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_wide__::rc_stream_c
} // namespace placeholders

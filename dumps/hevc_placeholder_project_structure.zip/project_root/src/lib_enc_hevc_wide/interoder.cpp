#include "lib_enc_hevc_wide/interoder.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_wide__::inter_coder_c
} // namespace placeholders

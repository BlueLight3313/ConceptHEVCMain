#include "lib_rc/qp_scheme_fixed.hpp"

namespace placeholders {
// Translation unit for: __lib_rc__::qp_scheme_fixed_c
} // namespace placeholders

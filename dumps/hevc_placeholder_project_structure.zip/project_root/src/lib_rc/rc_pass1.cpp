#include "lib_rc/rc_pass1.hpp"

namespace placeholders {
// Translation unit for: __lib_rc__::rc_pass1_c
} // namespace placeholders

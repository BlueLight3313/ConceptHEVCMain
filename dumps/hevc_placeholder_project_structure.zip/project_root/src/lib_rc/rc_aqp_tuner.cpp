#include "lib_rc/rc_aqp_tuner.hpp"

namespace placeholders {
// Translation unit for: __lib_rc__::rc_aqp_tuner_c
} // namespace placeholders

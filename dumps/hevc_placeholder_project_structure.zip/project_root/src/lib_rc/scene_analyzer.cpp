#include "lib_rc/scene_analyzer.hpp"

namespace placeholders {
// Translation unit for: __lib_rc__::scene_analyzer_c
} // namespace placeholders

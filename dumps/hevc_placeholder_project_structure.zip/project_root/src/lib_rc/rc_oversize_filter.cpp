#include "lib_rc/rc_oversize_filter.hpp"

namespace placeholders {
// Translation unit for: __lib_rc__::rc_oversize_filter_c
} // namespace placeholders

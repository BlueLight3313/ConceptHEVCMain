#include "lib_rc/rc_load.hpp"

namespace placeholders {
// Translation unit for: __lib_rc__::rc_load_c
} // namespace placeholders

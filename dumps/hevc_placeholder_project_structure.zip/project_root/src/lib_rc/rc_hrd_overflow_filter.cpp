#include "lib_rc/rc_hrd_overflow_filter.hpp"

namespace placeholders {
// Translation unit for: __lib_rc__::rc_hrd_overflow_filter_c
} // namespace placeholders

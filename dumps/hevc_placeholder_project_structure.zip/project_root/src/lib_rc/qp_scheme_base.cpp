#include "lib_rc/qp_scheme_base.hpp"

namespace placeholders {
// Translation unit for: __lib_rc__::qp_scheme_base_c
} // namespace placeholders

#include "lib_rc/rc_dump.hpp"

namespace placeholders {
// Translation unit for: __lib_rc__::rc_dump_c
} // namespace placeholders

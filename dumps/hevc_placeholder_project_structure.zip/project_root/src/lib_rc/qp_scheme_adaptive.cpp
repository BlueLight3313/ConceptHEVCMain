#include "lib_rc/qp_scheme_adaptive.hpp"

namespace placeholders {
// Translation unit for: __lib_rc__::qp_scheme_adaptive_c
} // namespace placeholders

#include "lib_rc/qp_scheme_flat.hpp"

namespace placeholders {
// Translation unit for: __lib_rc__::qp_scheme_flat_c
} // namespace placeholders

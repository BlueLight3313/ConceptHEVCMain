#include "lib_rc/intra_size_predictor.hpp"

namespace placeholders {
// Translation unit for: __lib_rc__::intra_size_predictor_c
} // namespace placeholders

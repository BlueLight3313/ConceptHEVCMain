#include "lib_rc/rc_env_member.hpp"

namespace placeholders {
// Translation unit for: __lib_rc__::rc_env_member_c
} // namespace placeholders

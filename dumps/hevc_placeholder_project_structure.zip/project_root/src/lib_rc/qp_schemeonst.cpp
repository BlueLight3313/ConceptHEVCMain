#include "lib_rc/qp_schemeonst.hpp"

namespace placeholders {
// Translation unit for: __lib_rc__::qp_scheme_const_c
} // namespace placeholders

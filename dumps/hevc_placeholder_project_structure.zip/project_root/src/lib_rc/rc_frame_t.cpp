#include "lib_rc/rc_frame_t.hpp"

namespace placeholders {
// Translation unit for: __lib_rc__::sliding_window<__lib_rc__::rc_frame_t>
} // namespace placeholders

#include "lib_rc/rc_base.hpp"

namespace placeholders {
// Translation unit for: __lib_rc__::rc_base_c
} // namespace placeholders

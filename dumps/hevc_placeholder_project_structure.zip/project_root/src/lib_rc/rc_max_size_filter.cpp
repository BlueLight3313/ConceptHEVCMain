#include "lib_rc/rc_max_size_filter.hpp"

namespace placeholders {
// Translation unit for: __lib_rc__::rc_max_size_filter_c
} // namespace placeholders

#include "lib_rc/pass1_frame_sequence.hpp"

namespace placeholders {
// Translation unit for: __lib_rc__::pass1_frame_sequence_c
} // namespace placeholders

#include "lib_rc/rc_wrap.hpp"

namespace placeholders {
// Translation unit for: __lib_rc__::rc_wrap_c
} // namespace placeholders

#include "lib_rc/cmplx_linear_size_predictor_1d.hpp"

namespace placeholders {
// Translation unit for: __lib_rc__::pass1_size_predictor_c<__lib_rc__::cmplx_linear_size_predictor_1d>
} // namespace placeholders

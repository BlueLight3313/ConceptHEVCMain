#include "lib_rc/rc_low_lat_tuner.hpp"

namespace placeholders {
// Translation unit for: __lib_rc__::rc_low_lat_tuner_c
} // namespace placeholders

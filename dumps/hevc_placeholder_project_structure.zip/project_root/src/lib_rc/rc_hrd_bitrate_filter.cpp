#include "lib_rc/rc_hrd_bitrate_filter.hpp"

namespace placeholders {
// Translation unit for: __lib_rc__::rc_hrd_bitrate_filter_c
} // namespace placeholders

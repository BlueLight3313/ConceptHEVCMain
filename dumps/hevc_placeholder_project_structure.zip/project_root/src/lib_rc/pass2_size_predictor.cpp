#include "lib_rc/pass2_size_predictor.hpp"

namespace placeholders {
// Translation unit for: __lib_rc__::pass2_size_predictor_c
} // namespace placeholders

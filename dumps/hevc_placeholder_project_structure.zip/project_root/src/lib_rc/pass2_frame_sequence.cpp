#include "lib_rc/pass2_frame_sequence.hpp"

namespace placeholders {
// Translation unit for: __lib_rc__::pass2_frame_sequence_c
} // namespace placeholders

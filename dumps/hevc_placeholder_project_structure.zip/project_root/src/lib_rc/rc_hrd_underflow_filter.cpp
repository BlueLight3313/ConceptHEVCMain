#include "lib_rc/rc_hrd_underflow_filter.hpp"

namespace placeholders {
// Translation unit for: __lib_rc__::rc_hrd_underflow_filter_c
} // namespace placeholders

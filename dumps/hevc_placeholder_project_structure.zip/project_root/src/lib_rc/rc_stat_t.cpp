#include "lib_rc/rc_stat_t.hpp"

namespace placeholders {
// Translation unit for: __lib_rc__::rc_stat_t
} // namespace placeholders

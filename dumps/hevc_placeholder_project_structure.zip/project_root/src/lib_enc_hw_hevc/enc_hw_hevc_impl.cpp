#include "lib_enc_hw_hevc/enc_hw_hevc_impl.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hw_hevc__::enc_hw_hevc_impl_c
} // namespace placeholders

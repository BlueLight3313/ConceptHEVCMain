#include "lib_enc_hw_hevc/stat.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hw_hevc__::enc_hw_hevc_impl_c::stat_c
} // namespace placeholders

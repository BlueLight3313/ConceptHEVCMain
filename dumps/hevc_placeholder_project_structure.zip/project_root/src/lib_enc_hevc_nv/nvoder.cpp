#include "lib_enc_hevc_nv/nvoder.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_nv__::nv_coder_c
} // namespace placeholders

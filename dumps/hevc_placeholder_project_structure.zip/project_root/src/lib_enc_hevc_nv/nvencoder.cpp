#include "lib_enc_hevc_nv/nvencoder.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_nv__::NvEncoder
} // namespace placeholders

#include "lib_enc_hevc_nv/nvdecoder.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_nv__::NvDecoder
} // namespace placeholders

#include "lib_enc_hevc_nv/cnvhwencoder.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_nv__::CNvHWEncoder
} // namespace placeholders

#include "lib_enc_hevc_nv/nvencexception.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_nv__::NVENCException
} // namespace placeholders

#include "lib_enc_hevc_nv/nvencodercustom.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_nv__::NvEncoderCustom
} // namespace placeholders

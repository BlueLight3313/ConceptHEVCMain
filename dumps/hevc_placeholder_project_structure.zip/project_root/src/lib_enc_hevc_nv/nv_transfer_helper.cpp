#include "lib_enc_hevc_nv/nv_transfer_helper.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_nv__::nv_transfer_helper_c
} // namespace placeholders

#include "lib_enc_hevc_common/struct_io_6.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_common__::struct_io_c<mc_enc_hevc_settings_t>
} // namespace placeholders

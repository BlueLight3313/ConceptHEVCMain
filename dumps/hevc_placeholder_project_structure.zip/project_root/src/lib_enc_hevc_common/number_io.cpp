#include "lib_enc_hevc_common/number_io.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_common__::number_io_c<int>
} // namespace placeholders

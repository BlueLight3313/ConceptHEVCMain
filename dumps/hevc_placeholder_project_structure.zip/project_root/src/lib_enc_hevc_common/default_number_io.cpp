#include "lib_enc_hevc_common/default_number_io.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_common__::default_number_io_c<int>
} // namespace placeholders

#include "lib_enc_hevc_common/qp_scheme_t_3ul.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_common__::enum_io_c<mc_enc_hevc_qp_scheme_t,__lib_rc__::qp_scheme_t,3ul>
} // namespace placeholders

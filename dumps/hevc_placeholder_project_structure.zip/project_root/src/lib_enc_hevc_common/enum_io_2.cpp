#include "lib_enc_hevc_common/enum_io_2.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_common__::enum_io_c<mc_enc_hevc_level_t,level_e,15ul>
} // namespace placeholders

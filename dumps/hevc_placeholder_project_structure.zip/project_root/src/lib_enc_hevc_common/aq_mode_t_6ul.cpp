#include "lib_enc_hevc_common/aq_mode_t_6ul.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_common__::enum_io_c<mc_enc_hevc_aq_mode_t,inque::aq_mode_t,6ul>
} // namespace placeholders

#include "lib_enc_hevc_common/enum_io_3.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_common__::enum_io_c<mc_enc_hevc_slice_mode_t,slice_mode_t,2ul>
} // namespace placeholders

#include "lib_enc_hevc_common/struct_io_7.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_common__::struct_io_c<layer_settings_s>
} // namespace placeholders

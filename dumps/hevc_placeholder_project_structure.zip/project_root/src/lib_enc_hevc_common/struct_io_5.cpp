#include "lib_enc_hevc_common/struct_io_5.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_common__::struct_io_c<settings_s>
} // namespace placeholders

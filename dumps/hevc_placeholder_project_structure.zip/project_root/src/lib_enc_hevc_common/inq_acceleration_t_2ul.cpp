#include "lib_enc_hevc_common/inq_acceleration_t_2ul.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_common__::enum_io_c<mc_enc_hevc_inq_acceleration_t,inque::inq_acceleration_t,2ul>
} // namespace placeholders

#include "lib_enc_hevc_common/enum_io_5.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_common__::enum_io_c<mc_enc_acceleration_t,hw_acceleration_t,4ul>
} // namespace placeholders

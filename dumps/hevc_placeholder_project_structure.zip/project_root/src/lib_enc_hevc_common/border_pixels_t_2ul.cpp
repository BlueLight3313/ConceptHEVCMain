#include "lib_enc_hevc_common/border_pixels_t_2ul.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_common__::enum_io_c<mc_enc_hevc_border_t,inque::border_pixels_t,2ul>
} // namespace placeholders

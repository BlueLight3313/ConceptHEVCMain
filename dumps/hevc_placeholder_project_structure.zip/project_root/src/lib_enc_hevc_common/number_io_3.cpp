#include "lib_enc_hevc_common/number_io_3.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_common__::number_io_c<uchar>
} // namespace placeholders

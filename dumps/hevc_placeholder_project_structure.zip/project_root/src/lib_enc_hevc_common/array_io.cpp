#include "lib_enc_hevc_common/array_io.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_common__::array_io_c
} // namespace placeholders

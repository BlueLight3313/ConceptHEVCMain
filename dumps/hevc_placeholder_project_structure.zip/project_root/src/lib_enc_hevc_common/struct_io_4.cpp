#include "lib_enc_hevc_common/struct_io_4.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_common__::struct_io_c<mc_content_light_level_t>
} // namespace placeholders

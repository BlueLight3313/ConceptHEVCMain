#include "lib_enc_hevc_common/struct_io.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_common__::struct_io_c<colorimetry_helper_c>
} // namespace placeholders

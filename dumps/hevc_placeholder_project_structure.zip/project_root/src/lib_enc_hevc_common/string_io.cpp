#include "lib_enc_hevc_common/string_io.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_common__::string_io_c
} // namespace placeholders

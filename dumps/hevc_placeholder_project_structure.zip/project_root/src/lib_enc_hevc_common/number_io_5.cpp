#include "lib_enc_hevc_common/number_io_5.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_common__::number_io_c<double>
} // namespace placeholders

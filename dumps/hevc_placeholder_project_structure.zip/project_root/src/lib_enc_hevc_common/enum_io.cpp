#include "lib_enc_hevc_common/enum_io.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_common__::enum_io_c<mc_enc_hevc_profile_t,profile_t,8ul>
} // namespace placeholders

#include "lib_enc_hevc_validation/profile_4k.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_validation__::profile_4k_c
} // namespace placeholders

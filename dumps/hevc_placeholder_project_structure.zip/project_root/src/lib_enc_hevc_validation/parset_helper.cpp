#include "lib_enc_hevc_validation/parset_helper.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_validation__::parset_helper_c
} // namespace placeholders

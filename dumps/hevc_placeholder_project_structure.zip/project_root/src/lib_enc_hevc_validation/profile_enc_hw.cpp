#include "lib_enc_hevc_validation/profile_enc_hw.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_validation__::profile_enc_hw_c
} // namespace placeholders

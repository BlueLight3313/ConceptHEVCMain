#include "lib_enc_hevc_validation/profile_main_intra.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_validation__::profile_main_intra_c
} // namespace placeholders

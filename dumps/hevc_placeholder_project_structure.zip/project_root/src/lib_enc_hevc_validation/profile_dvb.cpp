#include "lib_enc_hevc_validation/profile_dvb.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_validation__::profile_dvb_c
} // namespace placeholders

#include "lib_enc_hevc_validation/profile_multiview.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_validation__::profile_multiview_c
} // namespace placeholders

#include "lib_enc_hevc_validation/profile_hls_stereo.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_validation__::profile_hls_stereo_c
} // namespace placeholders

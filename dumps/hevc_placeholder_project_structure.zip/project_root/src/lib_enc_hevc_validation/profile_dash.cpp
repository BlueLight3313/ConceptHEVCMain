#include "lib_enc_hevc_validation/profile_dash.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_validation__::profile_dash_c
} // namespace placeholders

#include "lib_enc_hevc_validation/profile_hls.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_validation__::profile_hls_c
} // namespace placeholders

#include "lib_enc_hevc_validation/profile_atsc.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_validation__::profile_atsc_c
} // namespace placeholders

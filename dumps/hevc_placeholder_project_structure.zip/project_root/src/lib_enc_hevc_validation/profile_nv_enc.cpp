#include "lib_enc_hevc_validation/profile_nv_enc.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_validation__::profile_nv_enc_c
} // namespace placeholders

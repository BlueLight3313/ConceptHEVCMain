#include "lib_enc_hevc_validation/profile_miaf.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc_validation__::profile_miaf_c
} // namespace placeholders

#include "lib_inque_wide/src_frames_pool.hpp"

namespace placeholders {
// Translation unit for: __lib_inque_wide__::src_frames_pool_c
} // namespace placeholders

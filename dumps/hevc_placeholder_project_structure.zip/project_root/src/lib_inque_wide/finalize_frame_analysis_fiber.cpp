#include "lib_inque_wide/finalize_frame_analysis_fiber.hpp"

namespace placeholders {
// Translation unit for: __lib_inque_wide__::finalize_frame_analysis_fiber_c
} // namespace placeholders

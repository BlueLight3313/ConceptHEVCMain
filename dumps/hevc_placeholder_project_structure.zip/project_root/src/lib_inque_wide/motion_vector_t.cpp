#include "lib_inque_wide/motion_vector_t.hpp"

namespace placeholders {
// Translation unit for: __lib_inque_wide__::field_t<inque::motion_vector_t>
} // namespace placeholders

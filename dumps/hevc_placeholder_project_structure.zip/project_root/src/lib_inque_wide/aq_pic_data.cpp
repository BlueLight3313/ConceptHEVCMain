#include "lib_inque_wide/aq_pic_data.hpp"

namespace placeholders {
// Translation unit for: __lib_inque_wide__::aq_pic_data_c
} // namespace placeholders

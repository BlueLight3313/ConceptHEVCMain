#include "lib_inque_wide/ref_tracer.hpp"

namespace placeholders {
// Translation unit for: __lib_inque_wide__::ref_tracer_c
} // namespace placeholders

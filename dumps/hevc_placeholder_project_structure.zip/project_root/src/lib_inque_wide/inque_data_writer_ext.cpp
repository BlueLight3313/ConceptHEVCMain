#include "lib_inque_wide/inque_data_writer_ext.hpp"

namespace placeholders {
// Translation unit for: __lib_inque_wide__::inque_data_writer_ext_c
} // namespace placeholders

#include "lib_inque_wide/tfore.hpp"

namespace placeholders {
// Translation unit for: __lib_inque_wide__::tf_core_c
} // namespace placeholders

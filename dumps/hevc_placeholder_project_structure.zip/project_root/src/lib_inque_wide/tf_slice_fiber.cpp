#include "lib_inque_wide/tf_slice_fiber.hpp"

namespace placeholders {
// Translation unit for: __lib_inque_wide__::tf_slice_fiber_c
} // namespace placeholders

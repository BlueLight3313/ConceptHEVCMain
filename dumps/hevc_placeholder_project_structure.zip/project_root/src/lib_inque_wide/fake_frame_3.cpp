#include "lib_inque_wide/fake_frame_3.hpp"

namespace placeholders {
// Translation unit for: __lib_inque_wide__::pool_item_c<__lib_inque_wide__::fake_frame_c>
} // namespace placeholders

#include "lib_inque_wide/inqueontrol.hpp"

namespace placeholders {
// Translation unit for: __lib_inque_wide__::inque_control_c
} // namespace placeholders

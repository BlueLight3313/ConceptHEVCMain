#include "lib_inque_wide/spatial_aq.hpp"

namespace placeholders {
// Translation unit for: __lib_inque_wide__::spatial_aq_c
} // namespace placeholders

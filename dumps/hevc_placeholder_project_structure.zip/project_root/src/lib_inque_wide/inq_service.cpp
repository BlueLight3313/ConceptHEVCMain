#include "lib_inque_wide/inq_service.hpp"

namespace placeholders {
// Translation unit for: __lib_inque_wide__::inq_service_c
} // namespace placeholders

#include "lib_inque_wide/tf_me.hpp"

namespace placeholders {
// Translation unit for: __lib_inque_wide__::tf_me_c
} // namespace placeholders

#include "lib_inque_wide/filter_frame_fiber.hpp"

namespace placeholders {
// Translation unit for: __lib_inque_wide__::filter_frame_fiber_c
} // namespace placeholders

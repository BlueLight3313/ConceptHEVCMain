#include "lib_inque_wide/preanalysis_fiber.hpp"

namespace placeholders {
// Translation unit for: __lib_inque_wide__::preanalysis_fiber_c
} // namespace placeholders

#include "lib_inque_wide/pre_analyze_one_frame_fiber.hpp"

namespace placeholders {
// Translation unit for: __lib_inque_wide__::pre_analyze_one_frame_fiber_c
} // namespace placeholders

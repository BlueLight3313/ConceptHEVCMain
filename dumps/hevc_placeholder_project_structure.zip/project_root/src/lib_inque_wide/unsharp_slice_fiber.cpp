#include "lib_inque_wide/unsharp_slice_fiber.hpp"

namespace placeholders {
// Translation unit for: __lib_inque_wide__::unsharp_slice_fiber_c
} // namespace placeholders

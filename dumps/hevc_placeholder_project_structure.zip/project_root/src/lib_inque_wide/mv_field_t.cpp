#include "lib_inque_wide/mv_field_t.hpp"

namespace placeholders {
// Translation unit for: __lib_inque_wide__::mv_field_t
} // namespace placeholders

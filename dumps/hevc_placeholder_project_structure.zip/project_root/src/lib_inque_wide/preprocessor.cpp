#include "lib_inque_wide/preprocessor.hpp"

namespace placeholders {
// Translation unit for: __lib_inque_wide__::preprocessor_c
} // namespace placeholders

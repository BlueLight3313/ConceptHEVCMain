#include "lib_inque_wide/filter_slice_fiber.hpp"

namespace placeholders {
// Translation unit for: __lib_inque_wide__::filter_slice_fiber_c
} // namespace placeholders

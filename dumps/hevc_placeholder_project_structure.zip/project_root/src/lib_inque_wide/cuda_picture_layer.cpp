#include "lib_inque_wide/cuda_picture_layer.hpp"

namespace placeholders {
// Translation unit for: __lib_inque_wide__::cuda_picture_layer_c
} // namespace placeholders

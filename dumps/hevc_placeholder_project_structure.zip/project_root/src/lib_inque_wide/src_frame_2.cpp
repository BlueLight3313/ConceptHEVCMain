#include "lib_inque_wide/src_frame_2.hpp"

namespace placeholders {
// Translation unit for: __lib_inque_wide__::src_frame_c
} // namespace placeholders

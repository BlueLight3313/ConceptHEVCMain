#include "lib_inque_wide/external_qp_map.hpp"

namespace placeholders {
// Translation unit for: __lib_inque_wide__::external_qp_map_c
} // namespace placeholders

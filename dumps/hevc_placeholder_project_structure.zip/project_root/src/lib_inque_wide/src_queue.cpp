#include "lib_inque_wide/src_queue.hpp"

namespace placeholders {
// Translation unit for: __lib_inque_wide__::src_queue_c
} // namespace placeholders

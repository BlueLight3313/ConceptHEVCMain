#include "lib_inque_wide/ref_tracer_vector.hpp"

namespace placeholders {
// Translation unit for: __lib_inque_wide__::ref_tracer_vector_c
} // namespace placeholders

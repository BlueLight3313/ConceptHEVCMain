#include "lib_inque_wide/ref_trace_pic_data.hpp"

namespace placeholders {
// Translation unit for: __lib_inque_wide__::ref_trace_pic_data_c
} // namespace placeholders

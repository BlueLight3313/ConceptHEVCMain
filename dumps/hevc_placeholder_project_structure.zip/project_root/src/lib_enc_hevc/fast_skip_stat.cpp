#include "lib_enc_hevc/fast_skip_stat.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc__::fast_skip_stat_c
} // namespace placeholders

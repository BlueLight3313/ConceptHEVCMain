#include "lib_enc_hevc/cuoder.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc__::cu_coder_c
} // namespace placeholders

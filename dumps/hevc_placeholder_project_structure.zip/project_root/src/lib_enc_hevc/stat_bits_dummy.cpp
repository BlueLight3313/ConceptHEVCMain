#include "lib_enc_hevc/stat_bits_dummy.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc__::bit_counter_full_c<__lib_enc_hevc__::cabac_counter_c,__lib_enc_hevc__::stat_bits_dummy_c>
} // namespace placeholders

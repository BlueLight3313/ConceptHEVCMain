#include "lib_enc_hevc/buffer_speedontrol.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc__::buffer_speed_control_c
} // namespace placeholders

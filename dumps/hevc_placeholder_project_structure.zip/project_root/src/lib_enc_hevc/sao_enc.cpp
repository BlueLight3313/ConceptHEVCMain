#include "lib_enc_hevc/sao_enc.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc__::sao_enc_c
} // namespace placeholders

#include "lib_enc_hevc/rc_stream.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc__::rc_stream_c
} // namespace placeholders

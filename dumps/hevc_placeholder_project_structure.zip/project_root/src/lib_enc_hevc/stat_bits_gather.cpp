#include "lib_enc_hevc/stat_bits_gather.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc__::entropy_base_c<__lib_enc_hevc__::cabac_coder_c,__lib_enc_hevc__::stat_bits_gather_c>
} // namespace placeholders

#include "lib_enc_hevc/rc_stat_writerallback.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc__::rc_stat_writer_callback_c
} // namespace placeholders

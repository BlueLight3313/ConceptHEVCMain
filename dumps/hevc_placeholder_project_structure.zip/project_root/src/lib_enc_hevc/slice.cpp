#include "lib_enc_hevc/slice.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc__::slice_c
} // namespace placeholders

#include "lib_enc_hevc/ctuoder.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc__::ctu_coder_c
} // namespace placeholders

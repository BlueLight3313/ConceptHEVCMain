#include "lib_enc_hevc/interoder.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc__::inter_coder_c
} // namespace placeholders

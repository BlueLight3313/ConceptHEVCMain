#include "lib_enc_hevc/speedontrol.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc__::speed_control_c
} // namespace placeholders

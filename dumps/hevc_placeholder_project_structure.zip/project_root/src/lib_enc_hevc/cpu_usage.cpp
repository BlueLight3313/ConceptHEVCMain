#include "lib_enc_hevc/cpu_usage.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc__::cpu_usage_c
} // namespace placeholders

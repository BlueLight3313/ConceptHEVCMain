#include "lib_enc_hevc/cabacounter.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc__::cabac_counter_c
} // namespace placeholders

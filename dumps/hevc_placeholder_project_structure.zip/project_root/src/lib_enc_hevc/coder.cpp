#include "lib_enc_hevc/coder.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc__::coder_c
} // namespace placeholders

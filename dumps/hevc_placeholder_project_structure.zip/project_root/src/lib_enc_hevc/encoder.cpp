#include "lib_enc_hevc/encoder.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc__::encoder_c
} // namespace placeholders

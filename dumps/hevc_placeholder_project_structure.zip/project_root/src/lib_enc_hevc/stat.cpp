#include "lib_enc_hevc/stat.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc__::stat_c
} // namespace placeholders

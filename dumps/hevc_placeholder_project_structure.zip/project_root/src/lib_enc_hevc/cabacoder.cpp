#include "lib_enc_hevc/cabacoder.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc__::cabac_coder_c
} // namespace placeholders

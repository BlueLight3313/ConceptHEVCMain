#include "lib_enc_hevc/stream_data.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc__::stream_data_c
} // namespace placeholders

#include "lib_enc_hevc/dec_frame_storage.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc__::dec_frame_storage_c
} // namespace placeholders

#include "lib_enc_hevc/obuffer_flnss_verifier.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc__::encoder_c::obuffer_flnss_verifier_c
} // namespace placeholders

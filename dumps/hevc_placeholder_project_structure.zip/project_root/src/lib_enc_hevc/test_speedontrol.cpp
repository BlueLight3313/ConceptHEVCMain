#include "lib_enc_hevc/test_speedontrol.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc__::test_speed_control_c
} // namespace placeholders

#include "lib_enc_hevc/snr_layer.hpp"

namespace placeholders {
// Translation unit for: __lib_enc_hevc__::snr_layer_c
} // namespace placeholders
